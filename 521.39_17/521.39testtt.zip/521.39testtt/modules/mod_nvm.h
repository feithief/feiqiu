#ifndef __MOD_NVM_H
#define __MOD_NVM_H

#include <stdint.h>


uint8_t nvmTest(void);


#endif                                                                  /* __MOD_NVM_H                   */
