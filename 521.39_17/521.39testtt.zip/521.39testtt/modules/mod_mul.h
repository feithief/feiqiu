#ifndef __MOD_MUL_H
#define __MOD_MUL_H

#include <stdint.h>

uint32_t mulTest(void);
uint32_t macTest(void);

#endif                                                                  /* __MOD_MUL_H                   */
