#ifndef __MOD_DIVIDER_H
#define __MOD_DIVIDER_H

#include <stdint.h>

uint16_t dividerTest(void);



#endif                                                                  /* __MOD_DIVIDER_H               */
