#ifndef __MOD_CRC16_H
#define __MOD_CRC16_H

#include <stdint.h>


uint8_t crc16Test(void);



#endif                                                                  /* __MOD_CRC16_H                 */
