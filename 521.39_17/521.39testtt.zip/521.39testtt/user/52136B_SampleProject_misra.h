#ifndef _MISRAEX_H_
#define _MISRAEX_H_

/* ************************************************************** */
/* ********************* MISRA EXCLUSIONS *********************** */
/* ************************************************************** */


/* ************************************************************** 
*  MISRA rule   :  #Rule-No. to identify the specific MISRA rule
*  reason       :  reason for disabling it
*  ok, because  :  argument(s), why the code is still save
* ***************************************************************/     





#endif
