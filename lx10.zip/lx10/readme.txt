
LX3_update_LDF://20220527

compile success in ubuntu,setup cross-compile enviroment

LX3://2021.10.11

Delete other functions such as showroom
