touch `find ./* -name '*'`

