/********************************************************************************
** Form generated from reading UI file 'masterframe.ui'
**
** Created by: Qt User Interface Compiler version 5.10.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MASTERFRAME_H
#define UI_MASTERFRAME_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MasterFrame
{
public:
    QLabel *labelTitle;
    QLabel *labelAddress;
    QLabel *labelDimRamp;
    QSpinBox *spinBoxAdress;
    QSpinBox *spinBoxDimRamp;
    QSlider *horizontalSliderAdress;
    QSlider *horizontalSliderDimRamp;
    QFrame *frameCIE;
    QSlider *verticalSliderRed;
    QSlider *verticalSliderGreen;
    QSlider *verticalSliderBlue;
    QSlider *verticalSliderIntensity;
    QPushButton *pushButtonAccept;
    QPushButton *pushButtonCancel;
    QLabel *labelX;
    QLabel *labelY;
    QLabel *labelRed;
    QSpinBox *spinBoxBlue;
    QSpinBox *spinBoxIntensity;
    QSpinBox *spinBoxRed;
    QSpinBox *spinBoxGreen;
    QLabel *labelGreen;
    QLabel *labelBlue;
    QLabel *labelIntensity;
    QPushButton *pushButtonSyncMode;
    QPushButton *pushButtonCancel_2;
    QPushButton *pushButtonCancel_3;
    QGroupBox *groupBox_5;
    QPushButton *pushButtonColor185;
    QPushButton *pushButtonColor197;
    QPushButton *pushButtonColor217;
    QPushButton *pushButtonColor213;
    QPushButton *pushButtonColor188;
    QPushButton *pushButtonColor222;
    QPushButton *pushButtonColor214;
    QPushButton *pushButtonColor190;
    QPushButton *pushButtonColor212;
    QPushButton *pushButtonColor209;
    QPushButton *pushButtonColor207;
    QPushButton *pushButtonColor223;
    QPushButton *pushButtonColor201;
    QPushButton *pushButtonColor182;
    QPushButton *pushButtonColor198;
    QPushButton *pushButtonColor206;
    QPushButton *pushButtonColor218;
    QPushButton *pushButtonColor200;
    QPushButton *pushButtonColor181;
    QPushButton *pushButtonColor219;
    QPushButton *pushButtonColor221;
    QPushButton *pushButtonColor208;
    QPushButton *pushButtonColor186;
    QPushButton *pushButtonColor224;
    QPushButton *pushButtonColor225;
    QPushButton *pushButtonColor187;
    QPushButton *pushButtonColor195;
    QPushButton *pushButtonColor215;
    QPushButton *pushButtonColor199;
    QPushButton *pushButtonColor191;
    QPushButton *pushButtonColor204;
    QPushButton *pushButtonColor210;
    QPushButton *pushButtonColor211;
    QPushButton *pushButtonColor192;
    QPushButton *pushButtonColor193;
    QPushButton *pushButtonColor203;
    QPushButton *pushButtonColor220;
    QPushButton *pushButtonColor205;
    QPushButton *pushButtonColor184;
    QPushButton *pushButtonColor189;
    QPushButton *pushButtonColor216;
    QPushButton *pushButtonColor183;
    QPushButton *pushButtonColor202;
    QPushButton *pushButtonColor194;
    QPushButton *pushButtonColor196;
    QGroupBox *groupBox_3;
    QPushButton *pushButtonColor121;
    QPushButton *pushButtonColor132;
    QPushButton *pushButtonColor130;
    QPushButton *pushButtonColor108;
    QPushButton *pushButtonColor117;
    QPushButton *pushButtonColor94;
    QPushButton *pushButtonColor105;
    QPushButton *pushButtonColor120;
    QPushButton *pushButtonColor128;
    QPushButton *pushButtonColor99;
    QPushButton *pushButtonColor112;
    QPushButton *pushButtonColor104;
    QPushButton *pushButtonColor124;
    QPushButton *pushButtonColor97;
    QPushButton *pushButtonColor126;
    QPushButton *pushButtonColor115;
    QPushButton *pushButtonColor129;
    QPushButton *pushButtonColor131;
    QPushButton *pushButtonColor127;
    QPushButton *pushButtonColor135;
    QPushButton *pushButtonColor93;
    QPushButton *pushButtonColor103;
    QPushButton *pushButtonColor98;
    QPushButton *pushButtonColor111;
    QPushButton *pushButtonColor102;
    QPushButton *pushButtonColor114;
    QPushButton *pushButtonColor110;
    QPushButton *pushButtonColor118;
    QPushButton *pushButtonColor116;
    QPushButton *pushButtonColor100;
    QPushButton *pushButtonColor134;
    QPushButton *pushButtonColor125;
    QPushButton *pushButtonColor91;
    QPushButton *pushButtonColor109;
    QPushButton *pushButtonColor96;
    QPushButton *pushButtonColor113;
    QPushButton *pushButtonColor106;
    QPushButton *pushButtonColor107;
    QPushButton *pushButtonColor95;
    QPushButton *pushButtonColor101;
    QPushButton *pushButtonColor119;
    QPushButton *pushButtonColor123;
    QPushButton *pushButtonColor133;
    QPushButton *pushButtonColor122;
    QPushButton *pushButtonColor92;
    QGroupBox *groupBox_4;
    QPushButton *pushButtonColor161;
    QPushButton *pushButtonColor166;
    QPushButton *pushButtonColor167;
    QPushButton *pushButtonColor155;
    QPushButton *pushButtonColor138;
    QPushButton *pushButtonColor156;
    QPushButton *pushButtonColor153;
    QPushButton *pushButtonColor165;
    QPushButton *pushButtonColor170;
    QPushButton *pushButtonColor157;
    QPushButton *pushButtonColor150;
    QPushButton *pushButtonColor145;
    QPushButton *pushButtonColor137;
    QPushButton *pushButtonColor179;
    QPushButton *pushButtonColor146;
    QPushButton *pushButtonColor180;
    QPushButton *pushButtonColor164;
    QPushButton *pushButtonColor144;
    QPushButton *pushButtonColor151;
    QPushButton *pushButtonColor160;
    QPushButton *pushButtonColor175;
    QPushButton *pushButtonColor169;
    QPushButton *pushButtonColor140;
    QPushButton *pushButtonColor159;
    QPushButton *pushButtonColor163;
    QPushButton *pushButtonColor143;
    QPushButton *pushButtonColor177;
    QPushButton *pushButtonColor158;
    QPushButton *pushButtonColor149;
    QPushButton *pushButtonColor136;
    QPushButton *pushButtonColor178;
    QPushButton *pushButtonColor171;
    QPushButton *pushButtonColor154;
    QPushButton *pushButtonColor172;
    QPushButton *pushButtonColor168;
    QPushButton *pushButtonColor142;
    QPushButton *pushButtonColor152;
    QPushButton *pushButtonColor162;
    QPushButton *pushButtonColor141;
    QPushButton *pushButtonColor176;
    QPushButton *pushButtonColor148;
    QPushButton *pushButtonColor174;
    QPushButton *pushButtonColor147;
    QPushButton *pushButtonColor139;
    QPushButton *pushButtonColor173;
    QGroupBox *groupBox_6;
    QPushButton *pushButtonColor229;
    QPushButton *pushButtonColor248;
    QPushButton *pushButtonColor256;
    QPushButton *pushButtonColor226;
    QPushButton *pushButtonColor234;
    QPushButton *pushButtonColor244;
    QPushButton *pushButtonColor243;
    QPushButton *pushButtonColor255;
    QPushButton *pushButtonColor240;
    QPushButton *pushButtonColor233;
    QPushButton *pushButtonColor232;
    QPushButton *pushButtonColor228;
    QPushButton *pushButtonColor237;
    QPushButton *pushButtonColor245;
    QPushButton *pushButtonColor239;
    QPushButton *pushButtonColor242;
    QPushButton *pushButtonColor230;
    QPushButton *pushButtonColor241;
    QPushButton *pushButtonColor231;
    QPushButton *pushButtonColor238;
    QPushButton *pushButtonColor249;
    QPushButton *pushButtonColor227;
    QPushButton *pushButtonColor250;
    QPushButton *pushButtonColor236;
    QPushButton *pushButtonColor252;
    QPushButton *pushButtonColor246;
    QPushButton *pushButtonColor251;
    QPushButton *pushButtonColor254;
    QPushButton *pushButtonColor235;
    QPushButton *pushButtonColor253;
    QPushButton *pushButtonColor247;
    QGroupBox *groupBox_2;
    QPushButton *pushButtonColor75;
    QPushButton *pushButtonColor55;
    QPushButton *pushButtonColor85;
    QPushButton *pushButtonColor73;
    QPushButton *pushButtonColor46;
    QPushButton *pushButtonColor83;
    QPushButton *pushButtonColor66;
    QPushButton *pushButtonColor81;
    QPushButton *pushButtonColor50;
    QPushButton *pushButtonColor74;
    QPushButton *pushButtonColor56;
    QPushButton *pushButtonColor71;
    QPushButton *pushButtonColor72;
    QPushButton *pushButtonColor67;
    QPushButton *pushButtonColor89;
    QPushButton *pushButtonColor60;
    QPushButton *pushButtonColor87;
    QPushButton *pushButtonColor61;
    QPushButton *pushButtonColor63;
    QPushButton *pushButtonColor51;
    QPushButton *pushButtonColor80;
    QPushButton *pushButtonColor48;
    QPushButton *pushButtonColor76;
    QPushButton *pushButtonColor69;
    QPushButton *pushButtonColor54;
    QPushButton *pushButtonColor64;
    QPushButton *pushButtonColor57;
    QPushButton *pushButtonColor88;
    QPushButton *pushButtonColor70;
    QPushButton *pushButtonColor68;
    QPushButton *pushButtonColor49;
    QPushButton *pushButtonColor86;
    QPushButton *pushButtonColor78;
    QPushButton *pushButtonColor84;
    QPushButton *pushButtonColor90;
    QPushButton *pushButtonColor62;
    QPushButton *pushButtonColor79;
    QPushButton *pushButtonColor53;
    QPushButton *pushButtonColor82;
    QPushButton *pushButtonColor59;
    QPushButton *pushButtonColor77;
    QPushButton *pushButtonColor52;
    QPushButton *pushButtonColor65;
    QPushButton *pushButtonColor47;
    QPushButton *pushButtonColor58;
    QGroupBox *groupBox;
    QPushButton *pushButtonColor12;
    QPushButton *pushButtonColor39;
    QPushButton *pushButtonColor1;
    QPushButton *pushButtonColor38;
    QPushButton *pushButtonColor27;
    QPushButton *pushButtonColor41;
    QPushButton *pushButtonColor2;
    QPushButton *pushButtonColor28;
    QPushButton *pushButtonColor45;
    QPushButton *pushButtonColor32;
    QPushButton *pushButtonColor13;
    QPushButton *pushButtonColor24;
    QPushButton *pushButtonColor19;
    QPushButton *pushButtonColor42;
    QPushButton *pushButtonColor7;
    QPushButton *pushButtonColor37;
    QPushButton *pushButtonColor10;
    QPushButton *pushButtonColor25;
    QPushButton *pushButtonColor6;
    QPushButton *pushButtonColor29;
    QPushButton *pushButtonColor22;
    QPushButton *pushButtonColor44;
    QPushButton *pushButtonColor20;
    QPushButton *pushButtonColor14;
    QPushButton *pushButtonColor43;
    QPushButton *pushButtonColor8;
    QPushButton *pushButtonColor36;
    QPushButton *pushButtonColor4;
    QPushButton *pushButtonColor40;
    QPushButton *pushButtonColor33;
    QPushButton *pushButtonColor18;
    QPushButton *pushButtonColor30;
    QPushButton *pushButtonColor21;
    QPushButton *pushButtonColor26;
    QPushButton *pushButtonColor34;
    QPushButton *pushButtonColor23;
    QPushButton *pushButtonColor5;
    QPushButton *pushButtonColor17;
    QPushButton *pushButtonColor3;
    QPushButton *pushButtonColor11;
    QPushButton *pushButtonColor16;
    QPushButton *pushButtonColor31;
    QPushButton *pushButtonColor35;
    QPushButton *pushButtonColor15;
    QPushButton *pushButtonColor9;
    QPushButton *pushButtoncheck_mode;

    void setupUi(QWidget *MasterFrame)
    {
        if (MasterFrame->objectName().isEmpty())
            MasterFrame->setObjectName(QStringLiteral("MasterFrame"));
        MasterFrame->resize(1366, 768);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(MasterFrame->sizePolicy().hasHeightForWidth());
        MasterFrame->setSizePolicy(sizePolicy);
        QFont font;
        font.setFamily(QStringLiteral("Agency FB"));
        font.setPointSize(16);
        font.setBold(true);
        font.setWeight(75);
        MasterFrame->setFont(font);
        MasterFrame->setContextMenuPolicy(Qt::DefaultContextMenu);
        MasterFrame->setWindowOpacity(0.3);
        MasterFrame->setAutoFillBackground(false);
        labelTitle = new QLabel(MasterFrame);
        labelTitle->setObjectName(QStringLiteral("labelTitle"));
        labelTitle->setGeometry(QRect(0, 0, 1361, 71));
        QFont font1;
        labelTitle->setFont(font1);
        labelTitle->setStyleSheet(QLatin1String("QLabel{\n"
"font-size:32px;\n"
"color:rgb(29,165,219);\n"
"}"));
        labelTitle->setAlignment(Qt::AlignCenter);
        labelAddress = new QLabel(MasterFrame);
        labelAddress->setObjectName(QStringLiteral("labelAddress"));
        labelAddress->setGeometry(QRect(10, 80, 131, 42));
        labelAddress->setFont(font1);
        labelAddress->setStyleSheet(QLatin1String("QLabel{\n"
"font-size:22px;\n"
"color:rgb(29, 165,219);\n"
"}"));
        labelAddress->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        labelDimRamp = new QLabel(MasterFrame);
        labelDimRamp->setObjectName(QStringLiteral("labelDimRamp"));
        labelDimRamp->setGeometry(QRect(0, 160, 141, 42));
        labelDimRamp->setFont(font1);
        labelDimRamp->setStyleSheet(QLatin1String("QLabel{\n"
"font-size:22px;\n"
"color:rgb(29, 165,219);\n"
"}"));
        labelDimRamp->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        spinBoxAdress = new QSpinBox(MasterFrame);
        spinBoxAdress->setObjectName(QStringLiteral("spinBoxAdress"));
        spinBoxAdress->setGeometry(QRect(160, 80, 81, 41));
        spinBoxAdress->setStyleSheet(QLatin1String("QSpinBox{\n"
"border:1px solid rgb(29,165,219);\n"
"color:rgb(255,251,240);\n"
"font-size:22px;\n"
"background-color:rgba(0,0,0,0);\n"
"}\n"
"\n"
"QSpinBox::up-button\n"
"{\n"
"  width:0px;\n"
"  height:0px;\n"
"}\n"
"QSpinBox::down-button\n"
"{\n"
"  width:0px;\n"
"  height:0px;\n"
"}"));
        spinBoxAdress->setAlignment(Qt::AlignCenter);
        spinBoxAdress->setMaximum(65535);
        spinBoxAdress->setValue(20202);
        spinBoxDimRamp = new QSpinBox(MasterFrame);
        spinBoxDimRamp->setObjectName(QStringLiteral("spinBoxDimRamp"));
        spinBoxDimRamp->setGeometry(QRect(160, 160, 81, 41));
        spinBoxDimRamp->setStyleSheet(QLatin1String("QSpinBox{\n"
"border:1px solid rgb(29,165,219);\n"
"color:rgb(255,251,240);\n"
"font-size:22px;\n"
"background-color:rgba(0,0,0,0);\n"
"}\n"
"\n"
"QSpinBox::up-button\n"
"{\n"
"  width:0px;\n"
"  height:0px;\n"
"}\n"
"QSpinBox::down-button\n"
"{\n"
"  width:0px;\n"
"  height:0px;\n"
"}"));
        spinBoxDimRamp->setAlignment(Qt::AlignCenter);
        spinBoxDimRamp->setMaximum(255);
        spinBoxDimRamp->setValue(10);
        horizontalSliderAdress = new QSlider(MasterFrame);
        horizontalSliderAdress->setObjectName(QStringLiteral("horizontalSliderAdress"));
        horizontalSliderAdress->setGeometry(QRect(260, 83, 391, 35));
        horizontalSliderAdress->setStyleSheet(QLatin1String("QSlider::add-page:Horizontal\n"
"{\n"
"  background-color: rgba(87, 97, 106,0);\n"
"  height:40px;\n"
"}\n"
"QSlider::sub-page:Horizontal\n"
"{\n"
"background-color:qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 rgba(29,165,219, 180), stop:1 rgba(29,165,219, 180));\n"
"  height:40px;\n"
"}\n"
"QSlider::groove:Horizontal\n"
"{\n"
"  background:transparent;\n"
"  height:46px;\n"
"}\n"
"QSlider::handle:Horizontal\n"
"{\n"
"  background-color:rgb(29,165,219);\n"
"  height: 40px;\n"
"  width:30px;\n"
"}"));
        horizontalSliderAdress->setMaximum(65535);
        horizontalSliderAdress->setValue(1000);
        horizontalSliderAdress->setOrientation(Qt::Horizontal);
        horizontalSliderDimRamp = new QSlider(MasterFrame);
        horizontalSliderDimRamp->setObjectName(QStringLiteral("horizontalSliderDimRamp"));
        horizontalSliderDimRamp->setGeometry(QRect(260, 163, 391, 35));
        horizontalSliderDimRamp->setStyleSheet(QLatin1String("QSlider::add-page:Horizontal\n"
"{\n"
"  background-color: rgba(87, 97, 106,0);\n"
"  height:40px;\n"
"}\n"
"QSlider::sub-page:Horizontal\n"
"{\n"
"background-color:qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 rgba(29,165,219, 180), stop:1 rgba(29,165,219, 180));\n"
"  height:40px;\n"
"}\n"
"QSlider::groove:Horizontal\n"
"{\n"
"  background:transparent;\n"
"  height:46px;\n"
"}\n"
"QSlider::handle:Horizontal\n"
"{\n"
"  background-color:rgb(29,165,219);\n"
"  height: 40px;\n"
"  width:30px;\n"
"}"));
        horizontalSliderDimRamp->setMaximum(255);
        horizontalSliderDimRamp->setValue(2);
        horizontalSliderDimRamp->setOrientation(Qt::Horizontal);
        frameCIE = new QFrame(MasterFrame);
        frameCIE->setObjectName(QStringLiteral("frameCIE"));
        frameCIE->setGeometry(QRect(30, 410, 290, 325));
        frameCIE->setAutoFillBackground(false);
        frameCIE->setStyleSheet(QLatin1String("QFrame{\n"
"border:2px solid #0fbacd;\n"
"background-image: url(:/PICS/resources/CIE1391.bmp);\n"
"}"));
        frameCIE->setFrameShape(QFrame::StyledPanel);
        frameCIE->setFrameShadow(QFrame::Raised);
        verticalSliderRed = new QSlider(MasterFrame);
        verticalSliderRed->setObjectName(QStringLiteral("verticalSliderRed"));
        verticalSliderRed->setGeometry(QRect(368, 240, 35, 461));
        verticalSliderRed->setStyleSheet(QLatin1String("QSlider::sub-page:Vertical\n"
"{\n"
"  background-color: rgba(87, 97, 106,0);\n"
"  width:40px;\n"
"}\n"
"QSlider::add-page:Vertical\n"
"{\n"
"  background-color:qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 rgba(254,67,101, 140), stop:1 rgba(254,67,101, 200));\n"
"  width:40px;\n"
"}\n"
"QSlider::groove:Vertical\n"
"{\n"
"  background:transparent;\n"
"  width:46px;\n"
"}\n"
"QSlider::handle:Vertical\n"
"{\n"
"  background-color:rgb(254,67,101);\n"
"  width: 40px;\n"
"  height:30px;\n"
"}"));
        verticalSliderRed->setMaximum(255);
        verticalSliderRed->setValue(255);
        verticalSliderRed->setOrientation(Qt::Vertical);
        verticalSliderGreen = new QSlider(MasterFrame);
        verticalSliderGreen->setObjectName(QStringLiteral("verticalSliderGreen"));
        verticalSliderGreen->setGeometry(QRect(448, 240, 35, 461));
        verticalSliderGreen->setStyleSheet(QLatin1String("QSlider::sub-page:Vertical\n"
"{\n"
"  background-color: rgba(87, 97, 106,0);\n"
"  width:40px;\n"
"}\n"
"QSlider::add-page:Vertical\n"
"{\n"
"  background-color:qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 rgba(104,194,53, 140), stop:1 rgba(106,194,53, 200));\n"
"  width:40px;\n"
"}\n"
"QSlider::groove:Vertical\n"
"{\n"
"  background:transparent;\n"
"  width:46px;\n"
"}\n"
"QSlider::handle:Vertical\n"
"{\n"
"  background-color:rgb(106,194,53);\n"
"  width: 40px;\n"
"  height:30px;\n"
"}"));
        verticalSliderGreen->setMaximum(255);
        verticalSliderGreen->setValue(255);
        verticalSliderGreen->setOrientation(Qt::Vertical);
        verticalSliderBlue = new QSlider(MasterFrame);
        verticalSliderBlue->setObjectName(QStringLiteral("verticalSliderBlue"));
        verticalSliderBlue->setGeometry(QRect(528, 240, 35, 461));
        verticalSliderBlue->setStyleSheet(QLatin1String("QSlider::sub-page:Vertical\n"
"{\n"
"  background-color: rgba(87, 97, 106,0);\n"
"  width:40px;\n"
"}\n"
"QSlider::add-page:Vertical\n"
"{\n"
"  background-color:qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 rgba(0,95,255, 140), stop:1 rgba(0,95,255, 200));\n"
"  width:40px;\n"
"}\n"
"QSlider::groove:Vertical\n"
"{\n"
"  background:transparent;\n"
"  width:46px;\n"
"}\n"
"QSlider::handle:Vertical\n"
"{\n"
"  background-color:rgb(0,95,255);\n"
"  width: 40px;\n"
"  height:30px;\n"
"}"));
        verticalSliderBlue->setMaximum(255);
        verticalSliderBlue->setValue(255);
        verticalSliderBlue->setOrientation(Qt::Vertical);
        verticalSliderIntensity = new QSlider(MasterFrame);
        verticalSliderIntensity->setObjectName(QStringLiteral("verticalSliderIntensity"));
        verticalSliderIntensity->setGeometry(QRect(608, 240, 35, 461));
        verticalSliderIntensity->setStyleSheet(QLatin1String("QSlider::sub-page:Vertical\n"
"{\n"
"  background-color: rgba(87, 97, 106,0);\n"
"  width:40px;\n"
"}\n"
"QSlider::add-page:Vertical\n"
"{\n"
"  background-color:qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 rgba(29,165,219, 140), stop:1 rgba(29,165,219, 200));\n"
"  width:40px;\n"
"}\n"
"QSlider::groove:Vertical\n"
"{\n"
"  background:transparent;\n"
"  width:46px;\n"
"}\n"
"QSlider::handle:Vertical\n"
"{\n"
"  background-color:rgb(29,165,219);\n"
"  width: 40px;\n"
"  height:30px;\n"
"}"));
        verticalSliderIntensity->setMaximum(200);
        verticalSliderIntensity->setValue(200);
        verticalSliderIntensity->setOrientation(Qt::Vertical);
        verticalSliderIntensity->setInvertedAppearance(false);
        verticalSliderIntensity->setInvertedControls(false);
        pushButtonAccept = new QPushButton(MasterFrame);
        pushButtonAccept->setObjectName(QStringLiteral("pushButtonAccept"));
        pushButtonAccept->setGeometry(QRect(1030, 650, 131, 71));
        pushButtonAccept->setFont(font1);
        pushButtonAccept->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(255,251,240);\n"
"background:rgba(29, 165, 219, 0.3);\n"
"font-size:22px;\n"
"}"));
        pushButtonCancel = new QPushButton(MasterFrame);
        pushButtonCancel->setObjectName(QStringLiteral("pushButtonCancel"));
        pushButtonCancel->setGeometry(QRect(1180, 650, 131, 71));
        pushButtonCancel->setFont(font1);
        pushButtonCancel->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(255,251,240);\n"
"background:rgba(29, 165, 219, 0.3);\n"
"font-size:22px;\n"
"}"));
        labelX = new QLabel(MasterFrame);
        labelX->setObjectName(QStringLiteral("labelX"));
        labelX->setGeometry(QRect(40, 300, 131, 41));
        labelX->setFont(font1);
        labelX->setStyleSheet(QLatin1String("QLabel{\n"
"font-size:22px;\n"
"color:rgb(29, 165,219);\n"
"}"));
        labelY = new QLabel(MasterFrame);
        labelY->setObjectName(QStringLiteral("labelY"));
        labelY->setGeometry(QRect(40, 350, 131, 41));
        labelY->setFont(font1);
        labelY->setStyleSheet(QLatin1String("QLabel{\n"
"font-size:22px;\n"
"color:rgb(29, 165,219);\n"
"}"));
        labelRed = new QLabel(MasterFrame);
        labelRed->setObjectName(QStringLiteral("labelRed"));
        labelRed->setGeometry(QRect(360, 210, 51, 31));
        labelRed->setFont(font1);
        labelRed->setStyleSheet(QLatin1String("QLabel{\n"
"font-size:22px;\n"
"color:rgb(29,165,219);\n"
"}"));
        labelRed->setAlignment(Qt::AlignCenter);
        spinBoxBlue = new QSpinBox(MasterFrame);
        spinBoxBlue->setObjectName(QStringLiteral("spinBoxBlue"));
        spinBoxBlue->setGeometry(QRect(520, 710, 51, 41));
        spinBoxBlue->setStyleSheet(QLatin1String("QSpinBox{\n"
"border:1px solid rgb(29,165,219);\n"
"color:rgb(255,251,240);\n"
"font-size:22px;\n"
"background-color:rgba(0,0,0,0);\n"
"}\n"
"\n"
"QSpinBox::up-button\n"
"{\n"
"  width:0px;\n"
"  height:0px;\n"
"}\n"
"QSpinBox::down-button\n"
"{\n"
"  width:0px;\n"
"  height:0px;\n"
"}"));
        spinBoxBlue->setAlignment(Qt::AlignCenter);
        spinBoxBlue->setMaximum(255);
        spinBoxIntensity = new QSpinBox(MasterFrame);
        spinBoxIntensity->setObjectName(QStringLiteral("spinBoxIntensity"));
        spinBoxIntensity->setGeometry(QRect(600, 710, 51, 41));
        spinBoxIntensity->setStyleSheet(QLatin1String("QSpinBox{\n"
"border:1px solid rgb(29,165,219);\n"
"color:rgb(255,251,240);\n"
"font-size:22px;\n"
"background-color:rgba(0,0,0,0);\n"
"}\n"
"\n"
"QSpinBox::up-button\n"
"{\n"
"  width:0px;\n"
"  height:0px;\n"
"}\n"
"QSpinBox::down-button\n"
"{\n"
"  width:0px;\n"
"  height:0px;\n"
"}"));
        spinBoxIntensity->setAlignment(Qt::AlignCenter);
        spinBoxIntensity->setMaximum(200);
        spinBoxRed = new QSpinBox(MasterFrame);
        spinBoxRed->setObjectName(QStringLiteral("spinBoxRed"));
        spinBoxRed->setGeometry(QRect(360, 710, 51, 41));
        spinBoxRed->setFont(font1);
        spinBoxRed->setStyleSheet(QLatin1String("QSpinBox{\n"
"border:1px solid rgb(29,165,219);\n"
"color:rgb(255,251,240);\n"
"font-size:22px;\n"
"background-color:rgba(0,0,0,0);\n"
"}\n"
"\n"
"QSpinBox::up-button\n"
"{\n"
"  width:0px;\n"
"  height:0px;\n"
"}\n"
"QSpinBox::down-button\n"
"{\n"
"  width:0px;\n"
"  height:0px;\n"
"}"));
        spinBoxRed->setAlignment(Qt::AlignCenter);
        spinBoxRed->setMaximum(255);
        spinBoxRed->setValue(255);
        spinBoxGreen = new QSpinBox(MasterFrame);
        spinBoxGreen->setObjectName(QStringLiteral("spinBoxGreen"));
        spinBoxGreen->setGeometry(QRect(440, 710, 51, 41));
        spinBoxGreen->setFont(font1);
        spinBoxGreen->setStyleSheet(QLatin1String("QSpinBox{\n"
"border:1px solid rgb(29,165,219);\n"
"color:rgb(255,251,240);\n"
"font-size:22px;\n"
"background-color:rgba(0,0,0,0);\n"
"}\n"
"\n"
"QSpinBox::up-button\n"
"{\n"
"  width:0px;\n"
"  height:0px;\n"
"}\n"
"QSpinBox::down-button\n"
"{\n"
"  width:0px;\n"
"  height:0px;\n"
"}"));
        spinBoxGreen->setAlignment(Qt::AlignCenter);
        spinBoxGreen->setMaximum(255);
        labelGreen = new QLabel(MasterFrame);
        labelGreen->setObjectName(QStringLiteral("labelGreen"));
        labelGreen->setGeometry(QRect(440, 210, 51, 31));
        labelGreen->setFont(font1);
        labelGreen->setStyleSheet(QLatin1String("QLabel{\n"
"font-size:22px;\n"
"color:rgb(29,165,219);\n"
"}"));
        labelGreen->setAlignment(Qt::AlignCenter);
        labelBlue = new QLabel(MasterFrame);
        labelBlue->setObjectName(QStringLiteral("labelBlue"));
        labelBlue->setGeometry(QRect(520, 210, 51, 31));
        labelBlue->setFont(font1);
        labelBlue->setStyleSheet(QLatin1String("QLabel{\n"
"font-size:22px;\n"
"color:rgb(29,165,219);\n"
"}"));
        labelBlue->setAlignment(Qt::AlignCenter);
        labelIntensity = new QLabel(MasterFrame);
        labelIntensity->setObjectName(QStringLiteral("labelIntensity"));
        labelIntensity->setGeometry(QRect(580, 210, 91, 31));
        labelIntensity->setFont(font1);
        labelIntensity->setStyleSheet(QLatin1String("QLabel{\n"
"font-size:22px;\n"
"color:rgb(29,165,219);\n"
"}"));
        labelIntensity->setAlignment(Qt::AlignCenter);
        pushButtonSyncMode = new QPushButton(MasterFrame);
        pushButtonSyncMode->setObjectName(QStringLiteral("pushButtonSyncMode"));
        pushButtonSyncMode->setGeometry(QRect(880, 650, 131, 71));
        pushButtonCancel_2 = new QPushButton(MasterFrame);
        pushButtonCancel_2->setObjectName(QStringLiteral("pushButtonCancel_2"));
        pushButtonCancel_2->setGeometry(QRect(790, 650, 71, 71));
        pushButtonCancel_2->setFont(font1);
        pushButtonCancel_2->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(255,251,240);\n"
"background:rgba(29, 165, 219, 0.3);\n"
"font-size:22px;\n"
"}"));
        pushButtonCancel_3 = new QPushButton(MasterFrame);
        pushButtonCancel_3->setObjectName(QStringLiteral("pushButtonCancel_3"));
        pushButtonCancel_3->setGeometry(QRect(710, 650, 71, 71));
        pushButtonCancel_3->setFont(font1);
        pushButtonCancel_3->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(255,251,240);\n"
"background:rgba(29, 165, 219, 0.3);\n"
"font-size:22px;\n"
"}"));
        groupBox_5 = new QGroupBox(MasterFrame);
        groupBox_5->setObjectName(QStringLiteral("groupBox_5"));
        groupBox_5->setGeometry(QRect(700, 70, 620, 570));
        groupBox_5->setStyleSheet(QLatin1String("QGroupBox{\n"
"font-size:22px;\n"
"color:rgb(29, 165, 219);\n"
"background:transparent;\n"
"}"));
        pushButtonColor185 = new QPushButton(groupBox_5);
        pushButtonColor185->setObjectName(QStringLiteral("pushButtonColor185"));
        pushButtonColor185->setGeometry(QRect(500, 40, 101, 40));
        QFont font2;
        font2.setFamily(QStringLiteral("Agency FB"));
        font2.setPointSize(11);
        font2.setBold(true);
        font2.setWeight(75);
        pushButtonColor185->setFont(font2);
        pushButtonColor185->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(235	,109, 	156);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor197 = new QPushButton(groupBox_5);
        pushButtonColor197->setObjectName(QStringLiteral("pushButtonColor197"));
        pushButtonColor197->setGeometry(QRect(140, 220, 101, 40));
        pushButtonColor197->setFont(font2);
        pushButtonColor197->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(129	,255, 	109);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor217 = new QPushButton(groupBox_5);
        pushButtonColor217->setObjectName(QStringLiteral("pushButtonColor217"));
        pushButtonColor217->setGeometry(QRect(140, 460, 101, 40));
        pushButtonColor217->setFont(font2);
        pushButtonColor217->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(147	,222, 	225);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor213 = new QPushButton(groupBox_5);
        pushButtonColor213->setObjectName(QStringLiteral("pushButtonColor213"));
        pushButtonColor213->setGeometry(QRect(260, 400, 101, 40));
        pushButtonColor213->setFont(font2);
        pushButtonColor213->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(135	,163, 	255);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor188 = new QPushButton(groupBox_5);
        pushButtonColor188->setObjectName(QStringLiteral("pushButtonColor188"));
        pushButtonColor188->setGeometry(QRect(260, 100, 101, 40));
        pushButtonColor188->setFont(font2);
        pushButtonColor188->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(255	,161, 	228);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor222 = new QPushButton(groupBox_5);
        pushButtonColor222->setObjectName(QStringLiteral("pushButtonColor222"));
        pushButtonColor222->setGeometry(QRect(140, 520, 101, 40));
        pushButtonColor222->setFont(font2);
        pushButtonColor222->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(178	,255, 	90);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor214 = new QPushButton(groupBox_5);
        pushButtonColor214->setObjectName(QStringLiteral("pushButtonColor214"));
        pushButtonColor214->setGeometry(QRect(380, 400, 101, 40));
        pushButtonColor214->setFont(font2);
        pushButtonColor214->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(147	,186, 	255);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor190 = new QPushButton(groupBox_5);
        pushButtonColor190->setObjectName(QStringLiteral("pushButtonColor190"));
        pushButtonColor190->setGeometry(QRect(500, 100, 101, 40));
        pushButtonColor190->setFont(font2);
        pushButtonColor190->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(255	,229, 	255);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor212 = new QPushButton(groupBox_5);
        pushButtonColor212->setObjectName(QStringLiteral("pushButtonColor212"));
        pushButtonColor212->setGeometry(QRect(140, 400, 101, 40));
        pushButtonColor212->setFont(font2);
        pushButtonColor212->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(119	,149, 	255);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor209 = new QPushButton(groupBox_5);
        pushButtonColor209->setObjectName(QStringLiteral("pushButtonColor209"));
        pushButtonColor209->setGeometry(QRect(380, 340, 101, 40));
        pushButtonColor209->setFont(font2);
        pushButtonColor209->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(71	,147, 	255);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor207 = new QPushButton(groupBox_5);
        pushButtonColor207->setObjectName(QStringLiteral("pushButtonColor207"));
        pushButtonColor207->setGeometry(QRect(140, 340, 101, 40));
        pushButtonColor207->setFont(font2);
        pushButtonColor207->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(39	,147, 	231);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor223 = new QPushButton(groupBox_5);
        pushButtonColor223->setObjectName(QStringLiteral("pushButtonColor223"));
        pushButtonColor223->setGeometry(QRect(260, 520, 101, 40));
        pushButtonColor223->setFont(font2);
        pushButtonColor223->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(205	,156, 	74);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor201 = new QPushButton(groupBox_5);
        pushButtonColor201->setObjectName(QStringLiteral("pushButtonColor201"));
        pushButtonColor201->setGeometry(QRect(20, 280, 101, 40));
        pushButtonColor201->setFont(font2);
        pushButtonColor201->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(45	,242, 	109);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor182 = new QPushButton(groupBox_5);
        pushButtonColor182->setObjectName(QStringLiteral("pushButtonColor182"));
        pushButtonColor182->setGeometry(QRect(140, 40, 101, 40));
        pushButtonColor182->setFont(font2);
        pushButtonColor182->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(184	,109, 	84);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor198 = new QPushButton(groupBox_5);
        pushButtonColor198->setObjectName(QStringLiteral("pushButtonColor198"));
        pushButtonColor198->setGeometry(QRect(260, 220, 101, 40));
        pushButtonColor198->setFont(font2);
        pushButtonColor198->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(108	,255, 	109);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor206 = new QPushButton(groupBox_5);
        pushButtonColor206->setObjectName(QStringLiteral("pushButtonColor206"));
        pushButtonColor206->setGeometry(QRect(20, 340, 101, 40));
        pushButtonColor206->setFont(font2);
        pushButtonColor206->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(23	,147, 	205);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor218 = new QPushButton(groupBox_5);
        pushButtonColor218->setObjectName(QStringLiteral("pushButtonColor218"));
        pushButtonColor218->setGeometry(QRect(260, 460, 101, 40));
        pushButtonColor218->setFont(font2);
        pushButtonColor218->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(147	,234, 	179);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor200 = new QPushButton(groupBox_5);
        pushButtonColor200->setObjectName(QStringLiteral("pushButtonColor200"));
        pushButtonColor200->setGeometry(QRect(500, 220, 101, 40));
        pushButtonColor200->setFont(font2);
        pushButtonColor200->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(66	,255, 	109);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor181 = new QPushButton(groupBox_5);
        pushButtonColor181->setObjectName(QStringLiteral("pushButtonColor181"));
        pushButtonColor181->setGeometry(QRect(20, 40, 101, 40));
        pushButtonColor181->setFont(font2);
        pushButtonColor181->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(167	,109, 	60);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor219 = new QPushButton(groupBox_5);
        pushButtonColor219->setObjectName(QStringLiteral("pushButtonColor219"));
        pushButtonColor219->setGeometry(QRect(380, 460, 101, 40));
        pushButtonColor219->setFont(font2);
        pushButtonColor219->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(149	,246, 	158);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor221 = new QPushButton(groupBox_5);
        pushButtonColor221->setObjectName(QStringLiteral("pushButtonColor221"));
        pushButtonColor221->setGeometry(QRect(20, 520, 101, 40));
        pushButtonColor221->setFont(font2);
        pushButtonColor221->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(177	,255, 	116);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor208 = new QPushButton(groupBox_5);
        pushButtonColor208->setObjectName(QStringLiteral("pushButtonColor208"));
        pushButtonColor208->setGeometry(QRect(260, 340, 101, 40));
        pushButtonColor208->setFont(font2);
        pushButtonColor208->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(55	,147, 	251);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor186 = new QPushButton(groupBox_5);
        pushButtonColor186->setObjectName(QStringLiteral("pushButtonColor186"));
        pushButtonColor186->setGeometry(QRect(20, 100, 101, 40));
        pushButtonColor186->setFont(font2);
        pushButtonColor186->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(252	,111, 	180);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor224 = new QPushButton(groupBox_5);
        pushButtonColor224->setObjectName(QStringLiteral("pushButtonColor224"));
        pushButtonColor224->setGeometry(QRect(380, 520, 101, 40));
        pushButtonColor224->setFont(font2);
        pushButtonColor224->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(219	,147, 	53);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor225 = new QPushButton(groupBox_5);
        pushButtonColor225->setObjectName(QStringLiteral("pushButtonColor225"));
        pushButtonColor225->setGeometry(QRect(500, 520, 101, 40));
        pushButtonColor225->setFont(font2);
        pushButtonColor225->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(233	,138, 	32);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor187 = new QPushButton(groupBox_5);
        pushButtonColor187->setObjectName(QStringLiteral("pushButtonColor187"));
        pushButtonColor187->setGeometry(QRect(140, 100, 101, 40));
        pushButtonColor187->setFont(font2);
        pushButtonColor187->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(255	,129, 	204);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor195 = new QPushButton(groupBox_5);
        pushButtonColor195->setObjectName(QStringLiteral("pushButtonColor195"));
        pushButtonColor195->setGeometry(QRect(500, 160, 101, 40));
        pushButtonColor195->setFont(font2);
        pushButtonColor195->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(171	,255, 	125);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}163	,142, 	18"));
        pushButtonColor215 = new QPushButton(groupBox_5);
        pushButtonColor215->setObjectName(QStringLiteral("pushButtonColor215"));
        pushButtonColor215->setGeometry(QRect(500, 400, 101, 40));
        pushButtonColor215->setFont(font2);
        pushButtonColor215->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(147	,198, 	255);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor199 = new QPushButton(groupBox_5);
        pushButtonColor199->setObjectName(QStringLiteral("pushButtonColor199"));
        pushButtonColor199->setGeometry(QRect(380, 220, 101, 40));
        pushButtonColor199->setFont(font2);
        pushButtonColor199->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(87	,255, 	109);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor191 = new QPushButton(groupBox_5);
        pushButtonColor191->setObjectName(QStringLiteral("pushButtonColor191"));
        pushButtonColor191->setGeometry(QRect(20, 160, 101, 40));
        pushButtonColor191->setFont(font2);
        pushButtonColor191->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(255	,251, 	254);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor204 = new QPushButton(groupBox_5);
        pushButtonColor204->setObjectName(QStringLiteral("pushButtonColor204"));
        pushButtonColor204->setGeometry(QRect(380, 280, 101, 40));
        pushButtonColor204->setFont(font2);
        pushButtonColor204->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(23	,158, 	109);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor210 = new QPushButton(groupBox_5);
        pushButtonColor210->setObjectName(QStringLiteral("pushButtonColor210"));
        pushButtonColor210->setGeometry(QRect(500, 340, 101, 40));
        pushButtonColor210->setFont(font2);
        pushButtonColor210->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(87	,147, 	255);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor211 = new QPushButton(groupBox_5);
        pushButtonColor211->setObjectName(QStringLiteral("pushButtonColor211"));
        pushButtonColor211->setGeometry(QRect(20, 400, 101, 40));
        pushButtonColor211->setFont(font2);
        pushButtonColor211->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(103	,147, 	255);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor192 = new QPushButton(groupBox_5);
        pushButtonColor192->setObjectName(QStringLiteral("pushButtonColor192"));
        pushButtonColor192->setGeometry(QRect(140, 160, 101, 40));
        pushButtonColor192->setFont(font2);
        pushButtonColor192->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(234	,255, 	240);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor193 = new QPushButton(groupBox_5);
        pushButtonColor193->setObjectName(QStringLiteral("pushButtonColor193"));
        pushButtonColor193->setGeometry(QRect(260, 160, 101, 40));
        pushButtonColor193->setFont(font2);
        pushButtonColor193->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(213	,255, 	214);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor203 = new QPushButton(groupBox_5);
        pushButtonColor203->setObjectName(QStringLiteral("pushButtonColor203"));
        pushButtonColor203->setGeometry(QRect(260, 280, 101, 40));
        pushButtonColor203->setFont(font2);
        pushButtonColor203->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(23	,186, 	109);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor220 = new QPushButton(groupBox_5);
        pushButtonColor220->setObjectName(QStringLiteral("pushButtonColor220"));
        pushButtonColor220->setGeometry(QRect(500, 460, 101, 40));
        pushButtonColor220->setFont(font2);
        pushButtonColor220->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(163	,255, 	137);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor205 = new QPushButton(groupBox_5);
        pushButtonColor205->setObjectName(QStringLiteral("pushButtonColor205"));
        pushButtonColor205->setGeometry(QRect(500, 280, 101, 40));
        pushButtonColor205->setFont(font2);
        pushButtonColor205->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(23	,147, 	156 );\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor184 = new QPushButton(groupBox_5);
        pushButtonColor184->setObjectName(QStringLiteral("pushButtonColor184"));
        pushButtonColor184->setGeometry(QRect(380, 40, 101, 40));
        pushButtonColor184->setFont(font2);
        pushButtonColor184->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(218	,109, 	132);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor189 = new QPushButton(groupBox_5);
        pushButtonColor189->setObjectName(QStringLiteral("pushButtonColor189"));
        pushButtonColor189->setGeometry(QRect(380, 100, 101, 40));
        pushButtonColor189->setFont(font2);
        pushButtonColor189->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(255	,196,   252);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor216 = new QPushButton(groupBox_5);
        pushButtonColor216->setObjectName(QStringLiteral("pushButtonColor216"));
        pushButtonColor216->setGeometry(QRect(20, 460, 101, 40));
        pushButtonColor216->setFont(font2);
        pushButtonColor216->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(147	,210, 	254);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor183 = new QPushButton(groupBox_5);
        pushButtonColor183->setObjectName(QStringLiteral("pushButtonColor183"));
        pushButtonColor183->setGeometry(QRect(260, 40, 101, 40));
        pushButtonColor183->setFont(font2);
        pushButtonColor183->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(201	,109, 	108);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor202 = new QPushButton(groupBox_5);
        pushButtonColor202->setObjectName(QStringLiteral("pushButtonColor202"));
        pushButtonColor202->setGeometry(QRect(140, 280, 101, 40));
        pushButtonColor202->setFont(font2);
        pushButtonColor202->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(23	,214, 	109 );\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor194 = new QPushButton(groupBox_5);
        pushButtonColor194->setObjectName(QStringLiteral("pushButtonColor194"));
        pushButtonColor194->setGeometry(QRect(380, 160, 101, 40));
        pushButtonColor194->setFont(font2);
        pushButtonColor194->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(192	,255, 	183);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor196 = new QPushButton(groupBox_5);
        pushButtonColor196->setObjectName(QStringLiteral("pushButtonColor196"));
        pushButtonColor196->setGeometry(QRect(20, 220, 101, 40));
        pushButtonColor196->setFont(font2);
        pushButtonColor196->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(150	,255, 	110);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        groupBox_3 = new QGroupBox(MasterFrame);
        groupBox_3->setObjectName(QStringLiteral("groupBox_3"));
        groupBox_3->setGeometry(QRect(700, 70, 620, 570));
        groupBox_3->setStyleSheet(QLatin1String("QGroupBox{\n"
"font-size:22px;\n"
"color:rgb(29, 165, 219);\n"
"background:transparent;\n"
"}"));
        pushButtonColor121 = new QPushButton(groupBox_3);
        pushButtonColor121->setObjectName(QStringLiteral("pushButtonColor121"));
        pushButtonColor121->setGeometry(QRect(20, 400, 101, 40));
        pushButtonColor121->setFont(font2);
        pushButtonColor121->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(219	,48	, 0);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor132 = new QPushButton(groupBox_3);
        pushButtonColor132->setObjectName(QStringLiteral("pushButtonColor132"));
        pushButtonColor132->setGeometry(QRect(140, 520, 101, 40));
        pushButtonColor132->setFont(font2);
        pushButtonColor132->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(3	,59	, 162 );\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor130 = new QPushButton(groupBox_3);
        pushButtonColor130->setObjectName(QStringLiteral("pushButtonColor130"));
        pushButtonColor130->setGeometry(QRect(500, 460, 101, 40));
        pushButtonColor130->setFont(font2);
        pushButtonColor130->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(8	,25	, 144);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor108 = new QPushButton(groupBox_3);
        pushButtonColor108->setObjectName(QStringLiteral("pushButtonColor108"));
        pushButtonColor108->setGeometry(QRect(260, 220, 101, 40));
        pushButtonColor108->setFont(font2);
        pushButtonColor108->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(158	,255, 	0);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor117 = new QPushButton(groupBox_3);
        pushButtonColor117->setObjectName(QStringLiteral("pushButtonColor117"));
        pushButtonColor117->setGeometry(QRect(140, 340, 101, 40));
        pushButtonColor117->setFont(font2);
        pushButtonColor117->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(255	,140, 	0);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor94 = new QPushButton(groupBox_3);
        pushButtonColor94->setObjectName(QStringLiteral("pushButtonColor94"));
        pushButtonColor94->setGeometry(QRect(380, 40, 101, 40));
        pushButtonColor94->setFont(font2);
        pushButtonColor94->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(27	,255, 	255);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor105 = new QPushButton(groupBox_3);
        pushButtonColor105->setObjectName(QStringLiteral("pushButtonColor105"));
        pushButtonColor105->setGeometry(QRect(500, 160, 101, 40));
        pushButtonColor105->setFont(font2);
        pushButtonColor105->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(86	,255, 	0);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}46	,255, 	19"));
        pushButtonColor120 = new QPushButton(groupBox_3);
        pushButtonColor120->setObjectName(QStringLiteral("pushButtonColor120"));
        pushButtonColor120->setGeometry(QRect(500, 340, 101, 40));
        pushButtonColor120->setFont(font2);
        pushButtonColor120->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(231	,71	, 0);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor128 = new QPushButton(groupBox_3);
        pushButtonColor128->setObjectName(QStringLiteral("pushButtonColor128"));
        pushButtonColor128->setGeometry(QRect(260, 460, 101, 40));
        pushButtonColor128->setFont(font2);
        pushButtonColor128->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(35	,25	, 108);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor99 = new QPushButton(groupBox_3);
        pushButtonColor99->setObjectName(QStringLiteral("pushButtonColor99"));
        pushButtonColor99->setGeometry(QRect(380, 100, 101, 40));
        pushButtonColor99->setFont(font2);
        pushButtonColor99->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(0	,255, 	115);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor112 = new QPushButton(groupBox_3);
        pushButtonColor112->setObjectName(QStringLiteral("pushButtonColor112"));
        pushButtonColor112->setGeometry(QRect(140, 280, 101, 40));
        pushButtonColor112->setFont(font2);
        pushButtonColor112->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(254	,255, 	0);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor104 = new QPushButton(groupBox_3);
        pushButtonColor104->setObjectName(QStringLiteral("pushButtonColor104"));
        pushButtonColor104->setGeometry(QRect(380, 160, 101, 40));
        pushButtonColor104->setFont(font2);
        pushButtonColor104->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(62	,255, 	0);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor124 = new QPushButton(groupBox_3);
        pushButtonColor124->setObjectName(QStringLiteral("pushButtonColor124"));
        pushButtonColor124->setGeometry(QRect(380, 400, 101, 40));
        pushButtonColor124->setFont(font2);
        pushButtonColor124->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(163	,25	, 36);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor97 = new QPushButton(groupBox_3);
        pushButtonColor97->setObjectName(QStringLiteral("pushButtonColor97"));
        pushButtonColor97->setGeometry(QRect(140, 100, 101, 40));
        pushButtonColor97->setFont(font2);
        pushButtonColor97->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(0	,255, 	171);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor126 = new QPushButton(groupBox_3);
        pushButtonColor126->setObjectName(QStringLiteral("pushButtonColor126"));
        pushButtonColor126->setGeometry(QRect(20, 460, 101, 40));
        pushButtonColor126->setFont(font2);
        pushButtonColor126->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(99	,25	, 72);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor115 = new QPushButton(groupBox_3);
        pushButtonColor115->setObjectName(QStringLiteral("pushButtonColor115"));
        pushButtonColor115->setGeometry(QRect(500, 280, 101, 40));
        pushButtonColor115->setFont(font2);
        pushButtonColor115->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(255	,186, 	0);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor129 = new QPushButton(groupBox_3);
        pushButtonColor129->setObjectName(QStringLiteral("pushButtonColor129"));
        pushButtonColor129->setGeometry(QRect(380, 460, 101, 40));
        pushButtonColor129->setFont(font2);
        pushButtonColor129->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(9	,25	, 126 );\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor131 = new QPushButton(groupBox_3);
        pushButtonColor131->setObjectName(QStringLiteral("pushButtonColor131"));
        pushButtonColor131->setGeometry(QRect(20, 520, 101, 40));
        pushButtonColor131->setFont(font2);
        pushButtonColor131->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(6	,42	, 162);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor127 = new QPushButton(groupBox_3);
        pushButtonColor127->setObjectName(QStringLiteral("pushButtonColor127"));
        pushButtonColor127->setGeometry(QRect(140, 460, 101, 40));
        pushButtonColor127->setFont(font2);
        pushButtonColor127->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(67	,25	, 90);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor135 = new QPushButton(groupBox_3);
        pushButtonColor135->setObjectName(QStringLiteral("pushButtonColor135"));
        pushButtonColor135->setGeometry(QRect(500, 520, 101, 40));
        pushButtonColor135->setFont(font2);
        pushButtonColor135->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(3	,101, 	162 );\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor93 = new QPushButton(groupBox_3);
        pushButtonColor93->setObjectName(QStringLiteral("pushButtonColor93"));
        pushButtonColor93->setGeometry(QRect(260, 40, 101, 40));
        pushButtonColor93->setFont(font2);
        pushButtonColor93->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(39	,255, 	255);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor103 = new QPushButton(groupBox_3);
        pushButtonColor103->setObjectName(QStringLiteral("pushButtonColor103"));
        pushButtonColor103->setGeometry(QRect(260, 160, 101, 40));
        pushButtonColor103->setFont(font2);
        pushButtonColor103->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(38	,255, 	3);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor98 = new QPushButton(groupBox_3);
        pushButtonColor98->setObjectName(QStringLiteral("pushButtonColor98"));
        pushButtonColor98->setGeometry(QRect(260, 100, 101, 40));
        pushButtonColor98->setFont(font2);
        pushButtonColor98->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(0	,255, 	143 );\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor111 = new QPushButton(groupBox_3);
        pushButtonColor111->setObjectName(QStringLiteral("pushButtonColor111"));
        pushButtonColor111->setGeometry(QRect(20, 280, 101, 40));
        pushButtonColor111->setFont(font2);
        pushButtonColor111->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(230	,255, 	0);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor102 = new QPushButton(groupBox_3);
        pushButtonColor102->setObjectName(QStringLiteral("pushButtonColor102"));
        pushButtonColor102->setGeometry(QRect(140, 160, 101, 40));
        pushButtonColor102->setFont(font2);
        pushButtonColor102->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(4	,255, 	31);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor114 = new QPushButton(groupBox_3);
        pushButtonColor114->setObjectName(QStringLiteral("pushButtonColor114"));
        pushButtonColor114->setGeometry(QRect(380, 280, 101, 40));
        pushButtonColor114->setFont(font2);
        pushButtonColor114->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(255	,209, 	0);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor110 = new QPushButton(groupBox_3);
        pushButtonColor110->setObjectName(QStringLiteral("pushButtonColor110"));
        pushButtonColor110->setGeometry(QRect(500, 220, 101, 40));
        pushButtonColor110->setFont(font2);
        pushButtonColor110->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(206	,255, 	0 );\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor118 = new QPushButton(groupBox_3);
        pushButtonColor118->setObjectName(QStringLiteral("pushButtonColor118"));
        pushButtonColor118->setGeometry(QRect(260, 340, 101, 40));
        pushButtonColor118->setFont(font2);
        pushButtonColor118->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(255	,117, 	0 );\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor116 = new QPushButton(groupBox_3);
        pushButtonColor116->setObjectName(QStringLiteral("pushButtonColor116"));
        pushButtonColor116->setGeometry(QRect(20, 340, 101, 40));
        pushButtonColor116->setFont(font2);
        pushButtonColor116->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(255	,163, 	0);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor100 = new QPushButton(groupBox_3);
        pushButtonColor100->setObjectName(QStringLiteral("pushButtonColor100"));
        pushButtonColor100->setGeometry(QRect(500, 100, 101, 40));
        pushButtonColor100->setFont(font2);
        pushButtonColor100->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(0	,255, 	87 );\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor134 = new QPushButton(groupBox_3);
        pushButtonColor134->setObjectName(QStringLiteral("pushButtonColor134"));
        pushButtonColor134->setGeometry(QRect(380, 520, 101, 40));
        pushButtonColor134->setFont(font2);
        pushButtonColor134->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(3	,93	, 162);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor125 = new QPushButton(groupBox_3);
        pushButtonColor125->setObjectName(QStringLiteral("pushButtonColor125"));
        pushButtonColor125->setGeometry(QRect(500, 400, 101, 40));
        pushButtonColor125->setFont(font2);
        pushButtonColor125->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(131	,25	, 54 );\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}163	,142, 	18"));
        pushButtonColor91 = new QPushButton(groupBox_3);
        pushButtonColor91->setObjectName(QStringLiteral("pushButtonColor91"));
        pushButtonColor91->setGeometry(QRect(20, 40, 101, 40));
        pushButtonColor91->setFont(font2);
        pushButtonColor91->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(63	,255, 	255);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor109 = new QPushButton(groupBox_3);
        pushButtonColor109->setObjectName(QStringLiteral("pushButtonColor109"));
        pushButtonColor109->setGeometry(QRect(380, 220, 101, 40));
        pushButtonColor109->setFont(font2);
        pushButtonColor109->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(182	,255, 	0);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor96 = new QPushButton(groupBox_3);
        pushButtonColor96->setObjectName(QStringLiteral("pushButtonColor96"));
        pushButtonColor96->setGeometry(QRect(20, 100, 101, 40));
        pushButtonColor96->setFont(font2);
        pushButtonColor96->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(3	,255, 	199);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor113 = new QPushButton(groupBox_3);
        pushButtonColor113->setObjectName(QStringLiteral("pushButtonColor113"));
        pushButtonColor113->setGeometry(QRect(260, 280, 101, 40));
        pushButtonColor113->setFont(font2);
        pushButtonColor113->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(255	,232, 	0);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor106 = new QPushButton(groupBox_3);
        pushButtonColor106->setObjectName(QStringLiteral("pushButtonColor106"));
        pushButtonColor106->setGeometry(QRect(20, 220, 101, 40));
        pushButtonColor106->setFont(font2);
        pushButtonColor106->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(110	,255, 	0);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor107 = new QPushButton(groupBox_3);
        pushButtonColor107->setObjectName(QStringLiteral("pushButtonColor107"));
        pushButtonColor107->setGeometry(QRect(140, 220, 101, 40));
        pushButtonColor107->setFont(font2);
        pushButtonColor107->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(134	,255, 	0);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor95 = new QPushButton(groupBox_3);
        pushButtonColor95->setObjectName(QStringLiteral("pushButtonColor95"));
        pushButtonColor95->setGeometry(QRect(500, 40, 101, 40));
        pushButtonColor95->setFont(font2);
        pushButtonColor95->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(15	,255, 	227);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor101 = new QPushButton(groupBox_3);
        pushButtonColor101->setObjectName(QStringLiteral("pushButtonColor101"));
        pushButtonColor101->setGeometry(QRect(20, 160, 101, 40));
        pushButtonColor101->setFont(font2);
        pushButtonColor101->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(0	,255, 	59);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor119 = new QPushButton(groupBox_3);
        pushButtonColor119->setObjectName(QStringLiteral("pushButtonColor119"));
        pushButtonColor119->setGeometry(QRect(380, 340, 101, 40));
        pushButtonColor119->setFont(font2);
        pushButtonColor119->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(243	,94	, 0 );\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor123 = new QPushButton(groupBox_3);
        pushButtonColor123->setObjectName(QStringLiteral("pushButtonColor123"));
        pushButtonColor123->setGeometry(QRect(260, 400, 101, 40));
        pushButtonColor123->setFont(font2);
        pushButtonColor123->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(195	,25	, 18 );\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor133 = new QPushButton(groupBox_3);
        pushButtonColor133->setObjectName(QStringLiteral("pushButtonColor133"));
        pushButtonColor133->setGeometry(QRect(260, 520, 101, 40));
        pushButtonColor133->setFont(font2);
        pushButtonColor133->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(3	,76	, 162);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor122 = new QPushButton(groupBox_3);
        pushButtonColor122->setObjectName(QStringLiteral("pushButtonColor122"));
        pushButtonColor122->setGeometry(QRect(140, 400, 101, 40));
        pushButtonColor122->setFont(font2);
        pushButtonColor122->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(207	,25	, 0 );\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor92 = new QPushButton(groupBox_3);
        pushButtonColor92->setObjectName(QStringLiteral("pushButtonColor92"));
        pushButtonColor92->setGeometry(QRect(140, 40, 101, 40));
        pushButtonColor92->setFont(font2);
        pushButtonColor92->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(51	,255, 	255);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        groupBox_4 = new QGroupBox(MasterFrame);
        groupBox_4->setObjectName(QStringLiteral("groupBox_4"));
        groupBox_4->setGeometry(QRect(700, 70, 620, 570));
        groupBox_4->setStyleSheet(QLatin1String("QGroupBox{\n"
"font-size:22px;\n"
"color:rgb(29, 165, 219);\n"
"background:transparent;\n"
"}"));
        pushButtonColor161 = new QPushButton(groupBox_4);
        pushButtonColor161->setObjectName(QStringLiteral("pushButtonColor161"));
        pushButtonColor161->setGeometry(QRect(20, 340, 101, 40));
        pushButtonColor161->setFont(font2);
        pushButtonColor161->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(63	,241, 	120 );\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor166 = new QPushButton(groupBox_4);
        pushButtonColor166->setObjectName(QStringLiteral("pushButtonColor166"));
        pushButtonColor166->setGeometry(QRect(20, 400, 101, 40));
        pushButtonColor166->setFont(font2);
        pushButtonColor166->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(31	,255, 	60);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor167 = new QPushButton(groupBox_4);
        pushButtonColor167->setObjectName(QStringLiteral("pushButtonColor167"));
        pushButtonColor167->setGeometry(QRect(140, 400, 101, 40));
        pushButtonColor167->setFont(font2);
        pushButtonColor167->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(31	,255, 	44);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor155 = new QPushButton(groupBox_4);
        pushButtonColor155->setObjectName(QStringLiteral("pushButtonColor155"));
        pushButtonColor155->setGeometry(QRect(500, 220, 101, 40));
        pushButtonColor155->setFont(font2);
        pushButtonColor155->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(159	,97	, 36);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor138 = new QPushButton(groupBox_4);
        pushButtonColor138->setObjectName(QStringLiteral("pushButtonColor138"));
        pushButtonColor138->setGeometry(QRect(260, 40, 101, 40));
        pushButtonColor138->setFont(font2);
        pushButtonColor138->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(15	,125, 	137);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor156 = new QPushButton(groupBox_4);
        pushButtonColor156->setObjectName(QStringLiteral("pushButtonColor156"));
        pushButtonColor156->setGeometry(QRect(20, 280, 101, 40));
        pushButtonColor156->setFont(font2);
        pushButtonColor156->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(143	,121, 	64);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor153 = new QPushButton(groupBox_4);
        pushButtonColor153->setObjectName(QStringLiteral("pushButtonColor153"));
        pushButtonColor153->setGeometry(QRect(260, 220, 101, 40));
        pushButtonColor153->setFont(font2);
        pushButtonColor153->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(159	,46	, 44);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor165 = new QPushButton(groupBox_4);
        pushButtonColor165->setObjectName(QStringLiteral("pushButtonColor165"));
        pushButtonColor165->setGeometry(QRect(500, 340, 101, 40));
        pushButtonColor165->setFont(font2);
        pushButtonColor165->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(31	,255, 	76);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor170 = new QPushButton(groupBox_4);
        pushButtonColor170->setObjectName(QStringLiteral("pushButtonColor170"));
        pushButtonColor170->setGeometry(QRect(500, 400, 101, 40));
        pushButtonColor170->setFont(font2);
        pushButtonColor170->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(31	,237, 	12 );\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor157 = new QPushButton(groupBox_4);
        pushButtonColor157->setObjectName(QStringLiteral("pushButtonColor157"));
        pushButtonColor157->setGeometry(QRect(140, 280, 101, 40));
        pushButtonColor157->setFont(font2);
        pushButtonColor157->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(127	,145, 	92);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor150 = new QPushButton(groupBox_4);
        pushButtonColor150->setObjectName(QStringLiteral("pushButtonColor150"));
        pushButtonColor150->setGeometry(QRect(500, 160, 101, 40));
        pushButtonColor150->setFont(font2);
        pushButtonColor150->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(159	,82	, 56);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor145 = new QPushButton(groupBox_4);
        pushButtonColor145->setObjectName(QStringLiteral("pushButtonColor145"));
        pushButtonColor145->setGeometry(QRect(500, 100, 101, 40));
        pushButtonColor145->setFont(font2);
        pushButtonColor145->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(99	,142, 	76);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor137 = new QPushButton(groupBox_4);
        pushButtonColor137->setObjectName(QStringLiteral("pushButtonColor137"));
        pushButtonColor137->setGeometry(QRect(140, 40, 101, 40));
        pushButtonColor137->setFont(font2);
        pushButtonColor137->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(3	,117, 	144 );\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor179 = new QPushButton(groupBox_4);
        pushButtonColor179->setObjectName(QStringLiteral("pushButtonColor179"));
        pushButtonColor179->setGeometry(QRect(380, 520, 101, 40));
        pushButtonColor179->setFont(font2);
        pushButtonColor179->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(133	,109, 	12);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"} "));
        pushButtonColor146 = new QPushButton(groupBox_4);
        pushButtonColor146->setObjectName(QStringLiteral("pushButtonColor146"));
        pushButtonColor146->setGeometry(QRect(20, 160, 101, 40));
        pushButtonColor146->setFont(font2);
        pushButtonColor146->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(111	,130, 	72);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor180 = new QPushButton(groupBox_4);
        pushButtonColor180->setObjectName(QStringLiteral("pushButtonColor180"));
        pushButtonColor180->setGeometry(QRect(500, 520, 101, 40));
        pushButtonColor180->setFont(font2);
        pushButtonColor180->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(150	,109, 	36);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor164 = new QPushButton(groupBox_4);
        pushButtonColor164->setObjectName(QStringLiteral("pushButtonColor164"));
        pushButtonColor164->setGeometry(QRect(380, 340, 101, 40));
        pushButtonColor164->setFont(font2);
        pushButtonColor164->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(31	,255, 	92);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor144 = new QPushButton(groupBox_4);
        pushButtonColor144->setObjectName(QStringLiteral("pushButtonColor144"));
        pushButtonColor144->setGeometry(QRect(380, 100, 101, 40));
        pushButtonColor144->setFont(font2);
        pushButtonColor144->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(87	,142, 	80);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor151 = new QPushButton(groupBox_4);
        pushButtonColor151->setObjectName(QStringLiteral("pushButtonColor151"));
        pushButtonColor151->setGeometry(QRect(20, 220, 101, 40));
        pushButtonColor151->setFont(font2);
        pushButtonColor151->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(159	,70	, 52);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor160 = new QPushButton(groupBox_4);
        pushButtonColor160->setObjectName(QStringLiteral("pushButtonColor160"));
        pushButtonColor160->setGeometry(QRect(500, 280, 101, 40));
        pushButtonColor160->setFont(font2);
        pushButtonColor160->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(79	,217, 	120);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}163	,142, 	18"));
        pushButtonColor175 = new QPushButton(groupBox_4);
        pushButtonColor175->setObjectName(QStringLiteral("pushButtonColor175"));
        pushButtonColor175->setGeometry(QRect(500, 460, 101, 40));
        pushButtonColor175->setFont(font2);
        pushButtonColor175->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(65	,147, 	12);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}46	,255, 	19"));
        pushButtonColor169 = new QPushButton(groupBox_4);
        pushButtonColor169->setObjectName(QStringLiteral("pushButtonColor169"));
        pushButtonColor169->setGeometry(QRect(380, 400, 101, 40));
        pushButtonColor169->setFont(font2);
        pushButtonColor169->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(31	,255, 	12 );\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor140 = new QPushButton(groupBox_4);
        pushButtonColor140->setObjectName(QStringLiteral("pushButtonColor140"));
        pushButtonColor140->setGeometry(QRect(500, 40, 101, 40));
        pushButtonColor140->setFont(font2);
        pushButtonColor140->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(39	,141, 	123);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}46	,255, 	19"));
        pushButtonColor159 = new QPushButton(groupBox_4);
        pushButtonColor159->setObjectName(QStringLiteral("pushButtonColor159"));
        pushButtonColor159->setGeometry(QRect(380, 280, 101, 40));
        pushButtonColor159->setFont(font2);
        pushButtonColor159->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(95	,193, 	120 );\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor163 = new QPushButton(groupBox_4);
        pushButtonColor163->setObjectName(QStringLiteral("pushButtonColor163"));
        pushButtonColor163->setGeometry(QRect(260, 340, 101, 40));
        pushButtonColor163->setFont(font2);
        pushButtonColor163->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(31	,255, 	97);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor143 = new QPushButton(groupBox_4);
        pushButtonColor143->setObjectName(QStringLiteral("pushButtonColor143"));
        pushButtonColor143->setGeometry(QRect(260, 100, 101, 40));
        pushButtonColor143->setFont(font2);
        pushButtonColor143->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(75	,142, 	102);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor177 = new QPushButton(groupBox_4);
        pushButtonColor177->setObjectName(QStringLiteral("pushButtonColor177"));
        pushButtonColor177->setGeometry(QRect(140, 520, 101, 40));
        pushButtonColor177->setFont(font2);
        pushButtonColor177->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(99	,111, 	12);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor158 = new QPushButton(groupBox_4);
        pushButtonColor158->setObjectName(QStringLiteral("pushButtonColor158"));
        pushButtonColor158->setGeometry(QRect(260, 280, 101, 40));
        pushButtonColor158->setFont(font2);
        pushButtonColor158->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(111	,169, 	120);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor149 = new QPushButton(groupBox_4);
        pushButtonColor149->setObjectName(QStringLiteral("pushButtonColor149"));
        pushButtonColor149->setGeometry(QRect(380, 160, 101, 40));
        pushButtonColor149->setFont(font2);
        pushButtonColor149->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(147	,94	, 60 );\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor136 = new QPushButton(groupBox_4);
        pushButtonColor136->setObjectName(QStringLiteral("pushButtonColor136"));
        pushButtonColor136->setGeometry(QRect(20, 40, 101, 40));
        pushButtonColor136->setFont(font2);
        pushButtonColor136->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(3	,109, 	162);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor178 = new QPushButton(groupBox_4);
        pushButtonColor178->setObjectName(QStringLiteral("pushButtonColor178"));
        pushButtonColor178->setGeometry(QRect(260, 520, 101, 40));
        pushButtonColor178->setFont(font2);
        pushButtonColor178->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(116	,109, 	12);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor171 = new QPushButton(groupBox_4);
        pushButtonColor171->setObjectName(QStringLiteral("pushButtonColor171"));
        pushButtonColor171->setGeometry(QRect(20, 460, 101, 40));
        pushButtonColor171->setFont(font2);
        pushButtonColor171->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(31	,219, 	12);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor154 = new QPushButton(groupBox_4);
        pushButtonColor154->setObjectName(QStringLiteral("pushButtonColor154"));
        pushButtonColor154->setGeometry(QRect(380, 220, 101, 40));
        pushButtonColor154->setFont(font2);
        pushButtonColor154->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(159	,73	, 40);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor172 = new QPushButton(groupBox_4);
        pushButtonColor172->setObjectName(QStringLiteral("pushButtonColor172"));
        pushButtonColor172->setGeometry(QRect(140, 460, 101, 40));
        pushButtonColor172->setFont(font2);
        pushButtonColor172->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(31	,201, 	12);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor168 = new QPushButton(groupBox_4);
        pushButtonColor168->setObjectName(QStringLiteral("pushButtonColor168"));
        pushButtonColor168->setGeometry(QRect(260, 400, 101, 40));
        pushButtonColor168->setFont(font2);
        pushButtonColor168->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(31	,255, 	28);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor142 = new QPushButton(groupBox_4);
        pushButtonColor142->setObjectName(QStringLiteral("pushButtonColor142"));
        pushButtonColor142->setGeometry(QRect(140, 100, 101, 40));
        pushButtonColor142->setFont(font2);
        pushButtonColor142->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(63	,142, 	109);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor152 = new QPushButton(groupBox_4);
        pushButtonColor152->setObjectName(QStringLiteral("pushButtonColor152"));
        pushButtonColor152->setGeometry(QRect(140, 220, 101, 40));
        pushButtonColor152->setFont(font2);
        pushButtonColor152->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(159	,58	, 48);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor162 = new QPushButton(groupBox_4);
        pushButtonColor162->setObjectName(QStringLiteral("pushButtonColor162"));
        pushButtonColor162->setGeometry(QRect(140, 340, 101, 40));
        pushButtonColor162->setFont(font2);
        pushButtonColor162->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(47	,255, 	106);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor141 = new QPushButton(groupBox_4);
        pushButtonColor141->setObjectName(QStringLiteral("pushButtonColor141"));
        pushButtonColor141->setGeometry(QRect(20, 100, 101, 40));
        pushButtonColor141->setFont(font2);
        pushButtonColor141->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(51	,142, 	116);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor176 = new QPushButton(groupBox_4);
        pushButtonColor176->setObjectName(QStringLiteral("pushButtonColor176"));
        pushButtonColor176->setGeometry(QRect(20, 520, 101, 40));
        pushButtonColor176->setFont(font2);
        pushButtonColor176->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(82	,129, 	12);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor148 = new QPushButton(groupBox_4);
        pushButtonColor148->setObjectName(QStringLiteral("pushButtonColor148"));
        pushButtonColor148->setGeometry(QRect(260, 160, 101, 40));
        pushButtonColor148->setFont(font2);
        pushButtonColor148->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(135	,106, 	64);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}1"));
        pushButtonColor174 = new QPushButton(groupBox_4);
        pushButtonColor174->setObjectName(QStringLiteral("pushButtonColor174"));
        pushButtonColor174->setGeometry(QRect(380, 460, 101, 40));
        pushButtonColor174->setFont(font2);
        pushButtonColor174->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(48	,165, 	12 );\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor147 = new QPushButton(groupBox_4);
        pushButtonColor147->setObjectName(QStringLiteral("pushButtonColor147"));
        pushButtonColor147->setGeometry(QRect(140, 160, 101, 40));
        pushButtonColor147->setFont(font2);
        pushButtonColor147->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(123	,118, 	68);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor139 = new QPushButton(groupBox_4);
        pushButtonColor139->setObjectName(QStringLiteral("pushButtonColor139"));
        pushButtonColor139->setGeometry(QRect(380, 40, 101, 40));
        pushButtonColor139->setFont(font2);
        pushButtonColor139->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(27	,133, 	130 );\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor173 = new QPushButton(groupBox_4);
        pushButtonColor173->setObjectName(QStringLiteral("pushButtonColor173"));
        pushButtonColor173->setGeometry(QRect(260, 460, 101, 40));
        pushButtonColor173->setFont(font2);
        pushButtonColor173->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(31	,183, 	12);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        groupBox_6 = new QGroupBox(MasterFrame);
        groupBox_6->setObjectName(QStringLiteral("groupBox_6"));
        groupBox_6->setGeometry(QRect(700, 70, 620, 570));
        groupBox_6->setStyleSheet(QLatin1String("QGroupBox{\n"
"font-size:22px;\n"
"color:rgb(29, 165, 219);\n"
"background:transparent;\n"
"}"));
        pushButtonColor229 = new QPushButton(groupBox_6);
        pushButtonColor229->setObjectName(QStringLiteral("pushButtonColor229"));
        pushButtonColor229->setGeometry(QRect(380, 40, 101, 40));
        pushButtonColor229->setFont(font2);
        pushButtonColor229->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(213	,120, 	26);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor248 = new QPushButton(groupBox_6);
        pushButtonColor248->setObjectName(QStringLiteral("pushButtonColor248"));
        pushButtonColor248->setGeometry(QRect(260, 280, 101, 40));
        pushButtonColor248->setFont(font2);
        pushButtonColor248->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(11	,220, 	51);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor256 = new QPushButton(groupBox_6);
        pushButtonColor256->setObjectName(QStringLiteral("pushButtonColor256"));
        pushButtonColor256->setGeometry(QRect(20, 400, 101, 40));
        pushButtonColor256->setFont(font2);
        pushButtonColor256->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(83	,164, 	20);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor226 = new QPushButton(groupBox_6);
        pushButtonColor226->setObjectName(QStringLiteral("pushButtonColor226"));
        pushButtonColor226->setGeometry(QRect(20, 40, 101, 40));
        pushButtonColor226->setFont(font2);
        pushButtonColor226->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(247	,129, 	32);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor234 = new QPushButton(groupBox_6);
        pushButtonColor234->setObjectName(QStringLiteral("pushButtonColor234"));
        pushButtonColor234->setGeometry(QRect(380, 100, 101, 40));
        pushButtonColor234->setFont(font2);
        pushButtonColor234->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(128	,196, 	40);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor244 = new QPushButton(groupBox_6);
        pushButtonColor244->setObjectName(QStringLiteral("pushButtonColor244"));
        pushButtonColor244->setGeometry(QRect(380, 220, 101, 40));
        pushButtonColor244->setFont(font2);
        pushButtonColor244->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(47	,248, 	143);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor243 = new QPushButton(groupBox_6);
        pushButtonColor243->setObjectName(QStringLiteral("pushButtonColor243"));
        pushButtonColor243->setGeometry(QRect(260, 220, 101, 40));
        pushButtonColor243->setFont(font2);
        pushButtonColor243->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(56	,255, 	166);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor255 = new QPushButton(groupBox_6);
        pushButtonColor255->setObjectName(QStringLiteral("pushButtonColor255"));
        pushButtonColor255->setGeometry(QRect(500, 340, 101, 40));
        pushButtonColor255->setFont(font2);
        pushButtonColor255->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(75	,171, 	20);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor240 = new QPushButton(groupBox_6);
        pushButtonColor240->setObjectName(QStringLiteral("pushButtonColor240"));
        pushButtonColor240->setGeometry(QRect(500, 160, 101, 40));
        pushButtonColor240->setFont(font2);
        pushButtonColor240->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(56	,255, 	112 );\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor233 = new QPushButton(groupBox_6);
        pushButtonColor233->setObjectName(QStringLiteral("pushButtonColor233"));
        pushButtonColor233->setGeometry(QRect(260, 100, 101, 40));
        pushButtonColor233->setFont(font2);
        pushButtonColor233->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(145	,177, 	40);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor232 = new QPushButton(groupBox_6);
        pushButtonColor232->setObjectName(QStringLiteral("pushButtonColor232"));
        pushButtonColor232->setGeometry(QRect(140, 100, 101, 40));
        pushButtonColor232->setFont(font2);
        pushButtonColor232->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(162	,158, 	44);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor228 = new QPushButton(groupBox_6);
        pushButtonColor228->setObjectName(QStringLiteral("pushButtonColor228"));
        pushButtonColor228->setGeometry(QRect(260, 40, 101, 40));
        pushButtonColor228->setFont(font2);
        pushButtonColor228->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(230	,120, 	26);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor237 = new QPushButton(groupBox_6);
        pushButtonColor237->setObjectName(QStringLiteral("pushButtonColor237"));
        pushButtonColor237->setGeometry(QRect(140, 160, 101, 40));
        pushButtonColor237->setFont(font2);
        pushButtonColor237->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(89	,255, 	58);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor245 = new QPushButton(groupBox_6);
        pushButtonColor245->setObjectName(QStringLiteral("pushButtonColor245"));
        pushButtonColor245->setGeometry(QRect(500, 220, 101, 40));
        pushButtonColor245->setFont(font2);
        pushButtonColor245->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(38	,241, 	120);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor239 = new QPushButton(groupBox_6);
        pushButtonColor239->setObjectName(QStringLiteral("pushButtonColor239"));
        pushButtonColor239->setGeometry(QRect(380, 160, 101, 40));
        pushButtonColor239->setFont(font2);
        pushButtonColor239->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(67	,255, 	94);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor242 = new QPushButton(groupBox_6);
        pushButtonColor242->setObjectName(QStringLiteral("pushButtonColor242"));
        pushButtonColor242->setGeometry(QRect(140, 220, 101, 40));
        pushButtonColor242->setFont(font2);
        pushButtonColor242->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(56	,255, 	148);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor230 = new QPushButton(groupBox_6);
        pushButtonColor230->setObjectName(QStringLiteral("pushButtonColor230"));
        pushButtonColor230->setGeometry(QRect(500, 40, 101, 40));
        pushButtonColor230->setFont(font2);
        pushButtonColor230->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(196	,120, 	32);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}163	,142, 	18"));
        pushButtonColor241 = new QPushButton(groupBox_6);
        pushButtonColor241->setObjectName(QStringLiteral("pushButtonColor241"));
        pushButtonColor241->setGeometry(QRect(20, 220, 101, 40));
        pushButtonColor241->setFont(font2);
        pushButtonColor241->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(56	,255, 	130);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor231 = new QPushButton(groupBox_6);
        pushButtonColor231->setObjectName(QStringLiteral("pushButtonColor231"));
        pushButtonColor231->setGeometry(QRect(20, 100, 101, 40));
        pushButtonColor231->setFont(font2);
        pushButtonColor231->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(179	,139, 	38);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor238 = new QPushButton(groupBox_6);
        pushButtonColor238->setObjectName(QStringLiteral("pushButtonColor238"));
        pushButtonColor238->setGeometry(QRect(260, 160, 101, 40));
        pushButtonColor238->setFont(font2);
        pushButtonColor238->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(78	,255, 	76);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor249 = new QPushButton(groupBox_6);
        pushButtonColor249->setObjectName(QStringLiteral("pushButtonColor249"));
        pushButtonColor249->setGeometry(QRect(380, 280, 101, 40));
        pushButtonColor249->setFont(font2);
        pushButtonColor249->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(23	,213, 	28);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor227 = new QPushButton(groupBox_6);
        pushButtonColor227->setObjectName(QStringLiteral("pushButtonColor227"));
        pushButtonColor227->setGeometry(QRect(140, 40, 101, 40));
        pushButtonColor227->setFont(font2);
        pushButtonColor227->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(247	,120, 	26);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor250 = new QPushButton(groupBox_6);
        pushButtonColor250->setObjectName(QStringLiteral("pushButtonColor250"));
        pushButtonColor250->setGeometry(QRect(500, 280, 101, 40));
        pushButtonColor250->setFont(font2);
        pushButtonColor250->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(35	,206, 	20);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor236 = new QPushButton(groupBox_6);
        pushButtonColor236->setObjectName(QStringLiteral("pushButtonColor236"));
        pushButtonColor236->setGeometry(QRect(20, 160, 101, 40));
        pushButtonColor236->setFont(font2);
        pushButtonColor236->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(100	,252, 	40);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor252 = new QPushButton(groupBox_6);
        pushButtonColor252->setObjectName(QStringLiteral("pushButtonColor252"));
        pushButtonColor252->setGeometry(QRect(140, 340, 101, 40));
        pushButtonColor252->setFont(font2);
        pushButtonColor252->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(51	,192, 	13);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor246 = new QPushButton(groupBox_6);
        pushButtonColor246->setObjectName(QStringLiteral("pushButtonColor246"));
        pushButtonColor246->setGeometry(QRect(20, 280, 101, 40));
        pushButtonColor246->setFont(font2);
        pushButtonColor246->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(29	,234, 	97);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor251 = new QPushButton(groupBox_6);
        pushButtonColor251->setObjectName(QStringLiteral("pushButtonColor251"));
        pushButtonColor251->setGeometry(QRect(20, 340, 101, 40));
        pushButtonColor251->setFont(font2);
        pushButtonColor251->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(47	,199, 	16);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor254 = new QPushButton(groupBox_6);
        pushButtonColor254->setObjectName(QStringLiteral("pushButtonColor254"));
        pushButtonColor254->setGeometry(QRect(380, 340, 101, 40));
        pushButtonColor254->setFont(font2);
        pushButtonColor254->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(67	,178, 	20);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor235 = new QPushButton(groupBox_6);
        pushButtonColor235->setObjectName(QStringLiteral("pushButtonColor235"));
        pushButtonColor235->setGeometry(QRect(500, 100, 101, 40));
        pushButtonColor235->setFont(font2);
        pushButtonColor235->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(111	,215, 	40);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor253 = new QPushButton(groupBox_6);
        pushButtonColor253->setObjectName(QStringLiteral("pushButtonColor253"));
        pushButtonColor253->setGeometry(QRect(260, 340, 101, 40));
        pushButtonColor253->setFont(font2);
        pushButtonColor253->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(59	,185, 	20);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor247 = new QPushButton(groupBox_6);
        pushButtonColor247->setObjectName(QStringLiteral("pushButtonColor247"));
        pushButtonColor247->setGeometry(QRect(140, 280, 101, 40));
        pushButtonColor247->setFont(font2);
        pushButtonColor247->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(20	,227, 	74);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        groupBox_2 = new QGroupBox(MasterFrame);
        groupBox_2->setObjectName(QStringLiteral("groupBox_2"));
        groupBox_2->setGeometry(QRect(700, 70, 620, 570));
        groupBox_2->setStyleSheet(QLatin1String("QGroupBox{\n"
"font-size:22px;\n"
"color:rgb(29, 165, 219);\n"
"background:transparent;\n"
"}"));
        pushButtonColor75 = new QPushButton(groupBox_2);
        pushButtonColor75->setObjectName(QStringLiteral("pushButtonColor75"));
        pushButtonColor75->setGeometry(QRect(500, 340, 101, 40));
        pushButtonColor75->setFont(font2);
        pushButtonColor75->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(255	,96	, 0);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor55 = new QPushButton(groupBox_2);
        pushButtonColor55->setObjectName(QStringLiteral("pushButtonColor55"));
        pushButtonColor55->setGeometry(QRect(500, 100, 101, 40));
        pushButtonColor55->setFont(font2);
        pushButtonColor55->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(93	,111, 	150);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor85 = new QPushButton(groupBox_2);
        pushButtonColor85->setObjectName(QStringLiteral("pushButtonColor85"));
        pushButtonColor85->setGeometry(QRect(500, 460, 101, 40));
        pushButtonColor85->setFont(font2);
        pushButtonColor85->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(135	,255, 	126);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor73 = new QPushButton(groupBox_2);
        pushButtonColor73->setObjectName(QStringLiteral("pushButtonColor73"));
        pushButtonColor73->setGeometry(QRect(260, 340, 101, 40));
        pushButtonColor73->setFont(font2);
        pushButtonColor73->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(255	,64	, 0);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor46 = new QPushButton(groupBox_2);
        pushButtonColor46->setObjectName(QStringLiteral("pushButtonColor46"));
        pushButtonColor46->setGeometry(QRect(20, 40, 101, 40));
        pushButtonColor46->setFont(font2);
        pushButtonColor46->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(15	,255, 	112);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor83 = new QPushButton(groupBox_2);
        pushButtonColor83->setObjectName(QStringLiteral("pushButtonColor83"));
        pushButtonColor83->setGeometry(QRect(260, 460, 101, 40));
        pushButtonColor83->setFont(font2);
        pushButtonColor83->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(159	,224, 	62);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor66 = new QPushButton(groupBox_2);
        pushButtonColor66->setObjectName(QStringLiteral("pushButtonColor66"));
        pushButtonColor66->setGeometry(QRect(20, 280, 101, 40));
        pushButtonColor66->setFont(font2);
        pushButtonColor66->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(255	,0	, 107);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor81 = new QPushButton(groupBox_2);
        pushButtonColor81->setObjectName(QStringLiteral("pushButtonColor81"));
        pushButtonColor81->setGeometry(QRect(20, 460, 101, 40));
        pushButtonColor81->setFont(font2);
        pushButtonColor81->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(183	,192, 	0);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor50 = new QPushButton(groupBox_2);
        pushButtonColor50->setObjectName(QStringLiteral("pushButtonColor50"));
        pushButtonColor50->setGeometry(QRect(500, 40, 101, 40));
        pushButtonColor50->setFont(font2);
        pushButtonColor50->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(28	,231, 	150);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor74 = new QPushButton(groupBox_2);
        pushButtonColor74->setObjectName(QStringLiteral("pushButtonColor74"));
        pushButtonColor74->setGeometry(QRect(380, 340, 101, 40));
        pushButtonColor74->setFont(font2);
        pushButtonColor74->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(255	,80	, 0 );\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor56 = new QPushButton(groupBox_2);
        pushButtonColor56->setObjectName(QStringLiteral("pushButtonColor56"));
        pushButtonColor56->setGeometry(QRect(20, 160, 101, 40));
        pushButtonColor56->setFont(font2);
        pushButtonColor56->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(100	,100, 	150);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor71 = new QPushButton(groupBox_2);
        pushButtonColor71->setObjectName(QStringLiteral("pushButtonColor71"));
        pushButtonColor71->setGeometry(QRect(20, 340, 101, 40));
        pushButtonColor71->setFont(font2);
        pushButtonColor71->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(255	,32	, 0);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor72 = new QPushButton(groupBox_2);
        pushButtonColor72->setObjectName(QStringLiteral("pushButtonColor72"));
        pushButtonColor72->setGeometry(QRect(140, 340, 101, 40));
        pushButtonColor72->setFont(font2);
        pushButtonColor72->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(255	,48	, 0);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor67 = new QPushButton(groupBox_2);
        pushButtonColor67->setObjectName(QStringLiteral("pushButtonColor67"));
        pushButtonColor67->setGeometry(QRect(140, 280, 101, 40));
        pushButtonColor67->setFont(font2);
        pushButtonColor67->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(255	,0	, 70);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor89 = new QPushButton(groupBox_2);
        pushButtonColor89->setObjectName(QStringLiteral("pushButtonColor89"));
        pushButtonColor89->setGeometry(QRect(380, 520, 101, 40));
        pushButtonColor89->setFont(font2);
        pushButtonColor89->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(87	,255, 	255);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor60 = new QPushButton(groupBox_2);
        pushButtonColor60->setObjectName(QStringLiteral("pushButtonColor60"));
        pushButtonColor60->setGeometry(QRect(500, 160, 101, 40));
        pushButtonColor60->setFont(font2);
        pushButtonColor60->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(216	,44	, 222);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor87 = new QPushButton(groupBox_2);
        pushButtonColor87->setObjectName(QStringLiteral("pushButtonColor87"));
        pushButtonColor87->setGeometry(QRect(140, 520, 101, 40));
        pushButtonColor87->setFont(font2);
        pushButtonColor87->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(111	,255, 	190);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor61 = new QPushButton(groupBox_2);
        pushButtonColor61->setObjectName(QStringLiteral("pushButtonColor61"));
        pushButtonColor61->setGeometry(QRect(20, 220, 101, 40));
        pushButtonColor61->setFont(font2);
        pushButtonColor61->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(245	,30	, 240);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor63 = new QPushButton(groupBox_2);
        pushButtonColor63->setObjectName(QStringLiteral("pushButtonColor63"));
        pushButtonColor63->setGeometry(QRect(260, 220, 101, 40));
        pushButtonColor63->setFont(font2);
        pushButtonColor63->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(255	,0	, 218);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor51 = new QPushButton(groupBox_2);
        pushButtonColor51->setObjectName(QStringLiteral("pushButtonColor51"));
        pushButtonColor51->setGeometry(QRect(20, 100, 101, 40));
        pushButtonColor51->setFont(font2);
        pushButtonColor51->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(41	,207, 	150);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor80 = new QPushButton(groupBox_2);
        pushButtonColor80->setObjectName(QStringLiteral("pushButtonColor80"));
        pushButtonColor80->setGeometry(QRect(500, 400, 101, 40));
        pushButtonColor80->setFont(font2);
        pushButtonColor80->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(195	,176, 	0);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor48 = new QPushButton(groupBox_2);
        pushButtonColor48->setObjectName(QStringLiteral("pushButtonColor48"));
        pushButtonColor48->setGeometry(QRect(260, 40, 101, 40));
        pushButtonColor48->setFont(font2);
        pushButtonColor48->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(15	,255, 	138);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor76 = new QPushButton(groupBox_2);
        pushButtonColor76->setObjectName(QStringLiteral("pushButtonColor76"));
        pushButtonColor76->setGeometry(QRect(20, 400, 101, 40));
        pushButtonColor76->setFont(font2);
        pushButtonColor76->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(236	,112, 	0);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor69 = new QPushButton(groupBox_2);
        pushButtonColor69->setObjectName(QStringLiteral("pushButtonColor69"));
        pushButtonColor69->setGeometry(QRect(380, 280, 101, 40));
        pushButtonColor69->setFont(font2);
        pushButtonColor69->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(255	,0	, 5);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor54 = new QPushButton(groupBox_2);
        pushButtonColor54->setObjectName(QStringLiteral("pushButtonColor54"));
        pushButtonColor54->setGeometry(QRect(380, 100, 101, 40));
        pushButtonColor54->setFont(font2);
        pushButtonColor54->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(80	,135, 	150);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor64 = new QPushButton(groupBox_2);
        pushButtonColor64->setObjectName(QStringLiteral("pushButtonColor64"));
        pushButtonColor64->setGeometry(QRect(380, 220, 101, 40));
        pushButtonColor64->setFont(font2);
        pushButtonColor64->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(255	,0	, 181);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor57 = new QPushButton(groupBox_2);
        pushButtonColor57->setObjectName(QStringLiteral("pushButtonColor57"));
        pushButtonColor57->setGeometry(QRect(140, 160, 101, 40));
        pushButtonColor57->setFont(font2);
        pushButtonColor57->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(129	,86	, 168);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor88 = new QPushButton(groupBox_2);
        pushButtonColor88->setObjectName(QStringLiteral("pushButtonColor88"));
        pushButtonColor88->setGeometry(QRect(260, 520, 101, 40));
        pushButtonColor88->setFont(font2);
        pushButtonColor88->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(99	,255, 	222);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor70 = new QPushButton(groupBox_2);
        pushButtonColor70->setObjectName(QStringLiteral("pushButtonColor70"));
        pushButtonColor70->setGeometry(QRect(500, 280, 101, 40));
        pushButtonColor70->setFont(font2);
        pushButtonColor70->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(255	,16	, 0 );\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor68 = new QPushButton(groupBox_2);
        pushButtonColor68->setObjectName(QStringLiteral("pushButtonColor68"));
        pushButtonColor68->setGeometry(QRect(260, 280, 101, 40));
        pushButtonColor68->setFont(font2);
        pushButtonColor68->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(255	,0	, 33);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor49 = new QPushButton(groupBox_2);
        pushButtonColor49->setObjectName(QStringLiteral("pushButtonColor49"));
        pushButtonColor49->setGeometry(QRect(380, 40, 101, 40));
        pushButtonColor49->setFont(font2);
        pushButtonColor49->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(15	,255, 	150);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor86 = new QPushButton(groupBox_2);
        pushButtonColor86->setObjectName(QStringLiteral("pushButtonColor86"));
        pushButtonColor86->setGeometry(QRect(20, 520, 101, 40));
        pushButtonColor86->setFont(font2);
        pushButtonColor86->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(123	,255, 	158);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor78 = new QPushButton(groupBox_2);
        pushButtonColor78->setObjectName(QStringLiteral("pushButtonColor78"));
        pushButtonColor78->setGeometry(QRect(260, 400, 101, 40));
        pushButtonColor78->setFont(font2);
        pushButtonColor78->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(219	,144, 	0);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor84 = new QPushButton(groupBox_2);
        pushButtonColor84->setObjectName(QStringLiteral("pushButtonColor84"));
        pushButtonColor84->setGeometry(QRect(380, 460, 101, 40));
        pushButtonColor84->setFont(font2);
        pushButtonColor84->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(147	,240, 	94);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor90 = new QPushButton(groupBox_2);
        pushButtonColor90->setObjectName(QStringLiteral("pushButtonColor90"));
        pushButtonColor90->setGeometry(QRect(500, 520, 101, 40));
        pushButtonColor90->setFont(font2);
        pushButtonColor90->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(75	,255, 	255);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor62 = new QPushButton(groupBox_2);
        pushButtonColor62->setObjectName(QStringLiteral("pushButtonColor62"));
        pushButtonColor62->setGeometry(QRect(140, 220, 101, 40));
        pushButtonColor62->setFont(font2);
        pushButtonColor62->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(255	,0	, 255);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor79 = new QPushButton(groupBox_2);
        pushButtonColor79->setObjectName(QStringLiteral("pushButtonColor79"));
        pushButtonColor79->setGeometry(QRect(380, 400, 101, 40));
        pushButtonColor79->setFont(font2);
        pushButtonColor79->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(207	,160, 	0);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor53 = new QPushButton(groupBox_2);
        pushButtonColor53->setObjectName(QStringLiteral("pushButtonColor53"));
        pushButtonColor53->setGeometry(QRect(260, 100, 101, 40));
        pushButtonColor53->setFont(font2);
        pushButtonColor53->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(67	,159, 	150);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor82 = new QPushButton(groupBox_2);
        pushButtonColor82->setObjectName(QStringLiteral("pushButtonColor82"));
        pushButtonColor82->setGeometry(QRect(140, 460, 101, 40));
        pushButtonColor82->setFont(font2);
        pushButtonColor82->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(171	,208, 	30);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor59 = new QPushButton(groupBox_2);
        pushButtonColor59->setObjectName(QStringLiteral("pushButtonColor59"));
        pushButtonColor59->setGeometry(QRect(380, 160, 101, 40));
        pushButtonColor59->setFont(font2);
        pushButtonColor59->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(187	,58	, 204);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor77 = new QPushButton(groupBox_2);
        pushButtonColor77->setObjectName(QStringLiteral("pushButtonColor77"));
        pushButtonColor77->setGeometry(QRect(140, 400, 101, 40));
        pushButtonColor77->setFont(font2);
        pushButtonColor77->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(231	,128, 	0);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor52 = new QPushButton(groupBox_2);
        pushButtonColor52->setObjectName(QStringLiteral("pushButtonColor52"));
        pushButtonColor52->setGeometry(QRect(140, 100, 101, 40));
        pushButtonColor52->setFont(font2);
        pushButtonColor52->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(54	,183, 	150);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor65 = new QPushButton(groupBox_2);
        pushButtonColor65->setObjectName(QStringLiteral("pushButtonColor65"));
        pushButtonColor65->setGeometry(QRect(500, 220, 101, 40));
        pushButtonColor65->setFont(font2);
        pushButtonColor65->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(255	,0	, 144);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor47 = new QPushButton(groupBox_2);
        pushButtonColor47->setObjectName(QStringLiteral("pushButtonColor47"));
        pushButtonColor47->setGeometry(QRect(140, 40, 101, 40));
        pushButtonColor47->setFont(font2);
        pushButtonColor47->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(15	,255, 	125);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor58 = new QPushButton(groupBox_2);
        pushButtonColor58->setObjectName(QStringLiteral("pushButtonColor58"));
        pushButtonColor58->setGeometry(QRect(260, 160, 101, 40));
        pushButtonColor58->setFont(font2);
        pushButtonColor58->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(158	,72	, 186);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        groupBox = new QGroupBox(MasterFrame);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        groupBox->setGeometry(QRect(700, 70, 620, 570));
        groupBox->setStyleSheet(QLatin1String("QGroupBox{\n"
"font-size:22px;\n"
"color:rgb(29, 165, 219);\n"
"background:transparent;\n"
"}"));
        pushButtonColor12 = new QPushButton(groupBox);
        pushButtonColor12->setObjectName(QStringLiteral("pushButtonColor12"));
        pushButtonColor12->setGeometry(QRect(140, 160, 101, 40));
        pushButtonColor12->setFont(font2);
        pushButtonColor12->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(213	,74	, 11);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor39 = new QPushButton(groupBox);
        pushButtonColor39->setObjectName(QStringLiteral("pushButtonColor39"));
        pushButtonColor39->setGeometry(QRect(380, 460, 101, 40));
        pushButtonColor39->setFont(font2);
        pushButtonColor39->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(15	,255, 	21);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor1 = new QPushButton(groupBox);
        pushButtonColor1->setObjectName(QStringLiteral("pushButtonColor1"));
        pushButtonColor1->setGeometry(QRect(20, 40, 101, 40));
        pushButtonColor1->setFont(font2);
        pushButtonColor1->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(255	,0	, 0);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor38 = new QPushButton(groupBox);
        pushButtonColor38->setObjectName(QStringLiteral("pushButtonColor38"));
        pushButtonColor38->setGeometry(QRect(260, 460, 101, 40));
        pushButtonColor38->setFont(font2);
        pushButtonColor38->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(17	,255, 	21);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor27 = new QPushButton(groupBox);
        pushButtonColor27->setObjectName(QStringLiteral("pushButtonColor27"));
        pushButtonColor27->setGeometry(QRect(140, 340, 101, 40));
        pushButtonColor27->setFont(font2);
        pushButtonColor27->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(110	,216, 	16);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor41 = new QPushButton(groupBox);
        pushButtonColor41->setObjectName(QStringLiteral("pushButtonColor41"));
        pushButtonColor41->setGeometry(QRect(20, 520, 101, 40));
        pushButtonColor41->setFont(font2);
        pushButtonColor41->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(15	,255, 	47);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor2 = new QPushButton(groupBox);
        pushButtonColor2->setObjectName(QStringLiteral("pushButtonColor2"));
        pushButtonColor2->setGeometry(QRect(140, 40, 101, 40));
        pushButtonColor2->setFont(font2);
        pushButtonColor2->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(0	,255, 	0);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor28 = new QPushButton(groupBox);
        pushButtonColor28->setObjectName(QStringLiteral("pushButtonColor28"));
        pushButtonColor28->setGeometry(QRect(260, 340, 101, 40));
        pushButtonColor28->setFont(font2);
        pushButtonColor28->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(105	,224, 	16);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor45 = new QPushButton(groupBox);
        pushButtonColor45->setObjectName(QStringLiteral("pushButtonColor45"));
        pushButtonColor45->setGeometry(QRect(500, 520, 101, 40));
        pushButtonColor45->setFont(font2);
        pushButtonColor45->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(15	,255, 	99);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor32 = new QPushButton(groupBox);
        pushButtonColor32->setObjectName(QStringLiteral("pushButtonColor32"));
        pushButtonColor32->setGeometry(QRect(140, 400, 101, 40));
        pushButtonColor32->setFont(font2);
        pushButtonColor32->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(79	,255, 	18);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor13 = new QPushButton(groupBox);
        pushButtonColor13->setObjectName(QStringLiteral("pushButtonColor13"));
        pushButtonColor13->setGeometry(QRect(260, 160, 101, 40));
        pushButtonColor13->setFont(font2);
        pushButtonColor13->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(207	,82	, 13);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor24 = new QPushButton(groupBox);
        pushButtonColor24->setObjectName(QStringLiteral("pushButtonColor24"));
        pushButtonColor24->setGeometry(QRect(380, 280, 101, 40));
        pushButtonColor24->setFont(font2);
        pushButtonColor24->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(131	,190, 	15);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor19 = new QPushButton(groupBox);
        pushButtonColor19->setObjectName(QStringLiteral("pushButtonColor19"));
        pushButtonColor19->setGeometry(QRect(380, 220, 101, 40));
        pushButtonColor19->setFont(font2);
        pushButtonColor19->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(171	,130, 	18);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor42 = new QPushButton(groupBox);
        pushButtonColor42->setObjectName(QStringLiteral("pushButtonColor42"));
        pushButtonColor42->setGeometry(QRect(140, 520, 101, 40));
        pushButtonColor42->setFont(font2);
        pushButtonColor42->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(15	,255, 	60);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor7 = new QPushButton(groupBox);
        pushButtonColor7->setObjectName(QStringLiteral("pushButtonColor7"));
        pushButtonColor7->setGeometry(QRect(140, 100, 101, 40));
        pushButtonColor7->setFont(font2);
        pushButtonColor7->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(243	,34	, 1);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor37 = new QPushButton(groupBox);
        pushButtonColor37->setObjectName(QStringLiteral("pushButtonColor37"));
        pushButtonColor37->setGeometry(QRect(140, 460, 101, 40));
        pushButtonColor37->setFont(font2);
        pushButtonColor37->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(24	,255, 	20);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor10 = new QPushButton(groupBox);
        pushButtonColor10->setObjectName(QStringLiteral("pushButtonColor10"));
        pushButtonColor10->setGeometry(QRect(500, 100, 101, 40));
        pushButtonColor10->setFont(font2);
        pushButtonColor10->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(225	,58	, 7);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor25 = new QPushButton(groupBox);
        pushButtonColor25->setObjectName(QStringLiteral("pushButtonColor25"));
        pushButtonColor25->setGeometry(QRect(500, 280, 101, 40));
        pushButtonColor25->setFont(font2);
        pushButtonColor25->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(120	,200, 	15);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor6 = new QPushButton(groupBox);
        pushButtonColor6->setObjectName(QStringLiteral("pushButtonColor6"));
        pushButtonColor6->setGeometry(QRect(20, 100, 101, 40));
        pushButtonColor6->setFont(font2);
        pushButtonColor6->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(249	,26	, 0);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor29 = new QPushButton(groupBox);
        pushButtonColor29->setObjectName(QStringLiteral("pushButtonColor29"));
        pushButtonColor29->setGeometry(QRect(380, 340, 101, 40));
        pushButtonColor29->setFont(font2);
        pushButtonColor29->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(100	,232, 	17);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor22 = new QPushButton(groupBox);
        pushButtonColor22->setObjectName(QStringLiteral("pushButtonColor22"));
        pushButtonColor22->setGeometry(QRect(140, 280, 101, 40));
        pushButtonColor22->setFont(font2);
        pushButtonColor22->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(147	,166, 	16);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor44 = new QPushButton(groupBox);
        pushButtonColor44->setObjectName(QStringLiteral("pushButtonColor44"));
        pushButtonColor44->setGeometry(QRect(380, 520, 101, 40));
        pushButtonColor44->setFont(font2);
        pushButtonColor44->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(15	,255, 	86);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor20 = new QPushButton(groupBox);
        pushButtonColor20->setObjectName(QStringLiteral("pushButtonColor20"));
        pushButtonColor20->setGeometry(QRect(500, 220, 101, 40));
        pushButtonColor20->setFont(font2);
        pushButtonColor20->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(163	,142, 	18);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}163	,142, 	18"));
        pushButtonColor14 = new QPushButton(groupBox);
        pushButtonColor14->setObjectName(QStringLiteral("pushButtonColor14"));
        pushButtonColor14->setGeometry(QRect(380, 160, 101, 40));
        pushButtonColor14->setFont(font2);
        pushButtonColor14->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(201	,90	, 15);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor43 = new QPushButton(groupBox);
        pushButtonColor43->setObjectName(QStringLiteral("pushButtonColor43"));
        pushButtonColor43->setGeometry(QRect(260, 520, 101, 40));
        pushButtonColor43->setFont(font2);
        pushButtonColor43->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(15	,255, 	73);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor8 = new QPushButton(groupBox);
        pushButtonColor8->setObjectName(QStringLiteral("pushButtonColor8"));
        pushButtonColor8->setGeometry(QRect(260, 100, 101, 40));
        pushButtonColor8->setFont(font2);
        pushButtonColor8->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(237	,42	, 2);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor36 = new QPushButton(groupBox);
        pushButtonColor36->setObjectName(QStringLiteral("pushButtonColor36"));
        pushButtonColor36->setGeometry(QRect(20, 460, 101, 40));
        pushButtonColor36->setFont(font2);
        pushButtonColor36->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(35	,255, 	20);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor4 = new QPushButton(groupBox);
        pushButtonColor4->setObjectName(QStringLiteral("pushButtonColor4"));
        pushButtonColor4->setGeometry(QRect(380, 40, 101, 40));
        pushButtonColor4->setFont(font2);
        pushButtonColor4->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(255	,10	, 0);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor40 = new QPushButton(groupBox);
        pushButtonColor40->setObjectName(QStringLiteral("pushButtonColor40"));
        pushButtonColor40->setGeometry(QRect(500, 460, 101, 40));
        pushButtonColor40->setFont(font2);
        pushButtonColor40->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(15	,255, 	34);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor33 = new QPushButton(groupBox);
        pushButtonColor33->setObjectName(QStringLiteral("pushButtonColor33"));
        pushButtonColor33->setGeometry(QRect(260, 400, 101, 40));
        pushButtonColor33->setFont(font2);
        pushButtonColor33->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(68	,255, 	18);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor18 = new QPushButton(groupBox);
        pushButtonColor18->setObjectName(QStringLiteral("pushButtonColor18"));
        pushButtonColor18->setGeometry(QRect(260, 220, 101, 40));
        pushButtonColor18->setFont(font2);
        pushButtonColor18->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(177	,122, 	18);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor30 = new QPushButton(groupBox);
        pushButtonColor30->setObjectName(QStringLiteral("pushButtonColor30"));
        pushButtonColor30->setGeometry(QRect(500, 340, 101, 40));
        pushButtonColor30->setFont(font2);
        pushButtonColor30->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(95	,240, 	17 );\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor21 = new QPushButton(groupBox);
        pushButtonColor21->setObjectName(QStringLiteral("pushButtonColor21"));
        pushButtonColor21->setGeometry(QRect(20, 280, 101, 40));
        pushButtonColor21->setFont(font2);
        pushButtonColor21->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(155	,154, 	18);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor26 = new QPushButton(groupBox);
        pushButtonColor26->setObjectName(QStringLiteral("pushButtonColor26"));
        pushButtonColor26->setGeometry(QRect(20, 340, 101, 40));
        pushButtonColor26->setFont(font2);
        pushButtonColor26->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(115	,208, 	15);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor34 = new QPushButton(groupBox);
        pushButtonColor34->setObjectName(QStringLiteral("pushButtonColor34"));
        pushButtonColor34->setGeometry(QRect(380, 400, 101, 40));
        pushButtonColor34->setFont(font2);
        pushButtonColor34->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(57	,255, 	19);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor23 = new QPushButton(groupBox);
        pushButtonColor23->setObjectName(QStringLiteral("pushButtonColor23"));
        pushButtonColor23->setGeometry(QRect(260, 280, 101, 40));
        pushButtonColor23->setFont(font2);
        pushButtonColor23->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(139	,178, 	16);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor5 = new QPushButton(groupBox);
        pushButtonColor5->setObjectName(QStringLiteral("pushButtonColor5"));
        pushButtonColor5->setGeometry(QRect(500, 40, 101, 40));
        pushButtonColor5->setFont(font2);
        pushButtonColor5->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(255	,18	, 0);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor17 = new QPushButton(groupBox);
        pushButtonColor17->setObjectName(QStringLiteral("pushButtonColor17"));
        pushButtonColor17->setGeometry(QRect(140, 220, 101, 40));
        pushButtonColor17->setFont(font2);
        pushButtonColor17->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(183	,114, 	17);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor3 = new QPushButton(groupBox);
        pushButtonColor3->setObjectName(QStringLiteral("pushButtonColor3"));
        pushButtonColor3->setGeometry(QRect(260, 40, 101, 40));
        pushButtonColor3->setFont(font2);
        pushButtonColor3->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(0	,0	, 255);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor11 = new QPushButton(groupBox);
        pushButtonColor11->setObjectName(QStringLiteral("pushButtonColor11"));
        pushButtonColor11->setGeometry(QRect(20, 160, 101, 40));
        pushButtonColor11->setFont(font2);
        pushButtonColor11->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(219	,66	, 9);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor16 = new QPushButton(groupBox);
        pushButtonColor16->setObjectName(QStringLiteral("pushButtonColor16"));
        pushButtonColor16->setGeometry(QRect(20, 220, 101, 40));
        pushButtonColor16->setFont(font2);
        pushButtonColor16->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(189	,106, 	16);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor31 = new QPushButton(groupBox);
        pushButtonColor31->setObjectName(QStringLiteral("pushButtonColor31"));
        pushButtonColor31->setGeometry(QRect(20, 400, 101, 40));
        pushButtonColor31->setFont(font2);
        pushButtonColor31->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(90	,255, 	18);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor35 = new QPushButton(groupBox);
        pushButtonColor35->setObjectName(QStringLiteral("pushButtonColor35"));
        pushButtonColor35->setGeometry(QRect(500, 400, 101, 40));
        pushButtonColor35->setFont(font2);
        pushButtonColor35->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(46	,255, 	19);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}46	,255, 	19"));
        pushButtonColor15 = new QPushButton(groupBox);
        pushButtonColor15->setObjectName(QStringLiteral("pushButtonColor15"));
        pushButtonColor15->setGeometry(QRect(500, 160, 101, 40));
        pushButtonColor15->setFont(font2);
        pushButtonColor15->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(195	,98	, 15);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonColor9 = new QPushButton(groupBox);
        pushButtonColor9->setObjectName(QStringLiteral("pushButtonColor9"));
        pushButtonColor9->setGeometry(QRect(380, 100, 101, 40));
        pushButtonColor9->setFont(font2);
        pushButtonColor9->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-top-right-radius: 15px;\n"
"border-bottom-left-radius: 15px;\n"
"color:rgb(231	,50	, 4);\n"
"ont-size:22px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtoncheck_mode = new QPushButton(MasterFrame);
        pushButtoncheck_mode->setObjectName(QStringLiteral("pushButtoncheck_mode"));
        pushButtoncheck_mode->setGeometry(QRect(1200, 40, 121, 51));
        QFont font3;
        font3.setFamily(QStringLiteral("Ubuntu"));
        font3.setPointSize(14);
        font3.setBold(false);
        font3.setWeight(50);
        pushButtoncheck_mode->setFont(font3);

        retranslateUi(MasterFrame);

        QMetaObject::connectSlotsByName(MasterFrame);
    } // setupUi

    void retranslateUi(QWidget *MasterFrame)
    {
        MasterFrame->setWindowTitle(QApplication::translate("MasterFrame", "Form", nullptr));
        labelTitle->setText(QApplication::translate("MasterFrame", "BCM Master Control Panel", nullptr));
        labelAddress->setText(QApplication::translate("MasterFrame", "Address:", nullptr));
        labelDimRamp->setText(QApplication::translate("MasterFrame", "Dimming Ramp:", nullptr));
        pushButtonAccept->setText(QApplication::translate("MasterFrame", "Apply", nullptr));
        pushButtonCancel->setText(QApplication::translate("MasterFrame", "EXIT", nullptr));
        labelX->setText(QApplication::translate("MasterFrame", "X:", nullptr));
        labelY->setText(QApplication::translate("MasterFrame", "Y:", nullptr));
        labelRed->setText(QApplication::translate("MasterFrame", "RED", nullptr));
        labelGreen->setText(QApplication::translate("MasterFrame", "GREEN", nullptr));
        labelBlue->setText(QApplication::translate("MasterFrame", "BLUE", nullptr));
        labelIntensity->setText(QApplication::translate("MasterFrame", "INTENSITY", nullptr));
        pushButtonSyncMode->setText(QApplication::translate("MasterFrame", "Sync Signal\n"
"Immediate", nullptr));
        pushButtonCancel_2->setText(QApplication::translate("MasterFrame", "NEXT", nullptr));
        pushButtonCancel_3->setText(QApplication::translate("MasterFrame", "PREV", nullptr));
        groupBox_5->setTitle(QApplication::translate("MasterFrame", "Color Table:", nullptr));
        pushButtonColor185->setText(QApplication::translate("MasterFrame", "Color185", nullptr));
        pushButtonColor197->setText(QApplication::translate("MasterFrame", "Color197", nullptr));
        pushButtonColor217->setText(QApplication::translate("MasterFrame", "Color217", nullptr));
        pushButtonColor213->setText(QApplication::translate("MasterFrame", "Color213", nullptr));
        pushButtonColor188->setText(QApplication::translate("MasterFrame", "Color188", nullptr));
        pushButtonColor222->setText(QApplication::translate("MasterFrame", "Color222", nullptr));
        pushButtonColor214->setText(QApplication::translate("MasterFrame", "Color214", nullptr));
        pushButtonColor190->setText(QApplication::translate("MasterFrame", "Color190", nullptr));
        pushButtonColor212->setText(QApplication::translate("MasterFrame", "Color212", nullptr));
        pushButtonColor209->setText(QApplication::translate("MasterFrame", "Color209", nullptr));
        pushButtonColor207->setText(QApplication::translate("MasterFrame", "Color207", nullptr));
        pushButtonColor223->setText(QApplication::translate("MasterFrame", "Color223", nullptr));
        pushButtonColor201->setText(QApplication::translate("MasterFrame", "Color201", nullptr));
        pushButtonColor182->setText(QApplication::translate("MasterFrame", "Color182", nullptr));
        pushButtonColor198->setText(QApplication::translate("MasterFrame", "Color198", nullptr));
        pushButtonColor206->setText(QApplication::translate("MasterFrame", "Color206", nullptr));
        pushButtonColor218->setText(QApplication::translate("MasterFrame", "Color218", nullptr));
        pushButtonColor200->setText(QApplication::translate("MasterFrame", "Color200", nullptr));
        pushButtonColor181->setText(QApplication::translate("MasterFrame", "Color181", nullptr));
        pushButtonColor219->setText(QApplication::translate("MasterFrame", "Color219", nullptr));
        pushButtonColor221->setText(QApplication::translate("MasterFrame", "Color221", nullptr));
        pushButtonColor208->setText(QApplication::translate("MasterFrame", "Color208", nullptr));
        pushButtonColor186->setText(QApplication::translate("MasterFrame", "Color186", nullptr));
        pushButtonColor224->setText(QApplication::translate("MasterFrame", "Color224", nullptr));
        pushButtonColor225->setText(QApplication::translate("MasterFrame", "Color225", nullptr));
        pushButtonColor187->setText(QApplication::translate("MasterFrame", "Color187", nullptr));
        pushButtonColor195->setText(QApplication::translate("MasterFrame", "Color195", nullptr));
        pushButtonColor215->setText(QApplication::translate("MasterFrame", "Color215", nullptr));
        pushButtonColor199->setText(QApplication::translate("MasterFrame", "Color199", nullptr));
        pushButtonColor191->setText(QApplication::translate("MasterFrame", "Color191", nullptr));
        pushButtonColor204->setText(QApplication::translate("MasterFrame", "Color204", nullptr));
        pushButtonColor210->setText(QApplication::translate("MasterFrame", "Color210", nullptr));
        pushButtonColor211->setText(QApplication::translate("MasterFrame", "Color211", nullptr));
        pushButtonColor192->setText(QApplication::translate("MasterFrame", "Color192", nullptr));
        pushButtonColor193->setText(QApplication::translate("MasterFrame", "Color193", nullptr));
        pushButtonColor203->setText(QApplication::translate("MasterFrame", "Color203", nullptr));
        pushButtonColor220->setText(QApplication::translate("MasterFrame", "Color220", nullptr));
        pushButtonColor205->setText(QApplication::translate("MasterFrame", "Color205", nullptr));
        pushButtonColor184->setText(QApplication::translate("MasterFrame", "Color184", nullptr));
        pushButtonColor189->setText(QApplication::translate("MasterFrame", "Color189", nullptr));
        pushButtonColor216->setText(QApplication::translate("MasterFrame", "Color216", nullptr));
        pushButtonColor183->setText(QApplication::translate("MasterFrame", "Color183", nullptr));
        pushButtonColor202->setText(QApplication::translate("MasterFrame", "Color202", nullptr));
        pushButtonColor194->setText(QApplication::translate("MasterFrame", "Color194", nullptr));
        pushButtonColor196->setText(QApplication::translate("MasterFrame", "Color196", nullptr));
        groupBox_3->setTitle(QApplication::translate("MasterFrame", "Color Table:", nullptr));
        pushButtonColor121->setText(QApplication::translate("MasterFrame", "Color121", nullptr));
        pushButtonColor132->setText(QApplication::translate("MasterFrame", "Color132", nullptr));
        pushButtonColor130->setText(QApplication::translate("MasterFrame", "Color130", nullptr));
        pushButtonColor108->setText(QApplication::translate("MasterFrame", "Color108", nullptr));
        pushButtonColor117->setText(QApplication::translate("MasterFrame", "Color117", nullptr));
        pushButtonColor94->setText(QApplication::translate("MasterFrame", "Color94", nullptr));
        pushButtonColor105->setText(QApplication::translate("MasterFrame", "Color105", nullptr));
        pushButtonColor120->setText(QApplication::translate("MasterFrame", "Color120", nullptr));
        pushButtonColor128->setText(QApplication::translate("MasterFrame", "Color128", nullptr));
        pushButtonColor99->setText(QApplication::translate("MasterFrame", "Color99", nullptr));
        pushButtonColor112->setText(QApplication::translate("MasterFrame", "Color112", nullptr));
        pushButtonColor104->setText(QApplication::translate("MasterFrame", "Color104", nullptr));
        pushButtonColor124->setText(QApplication::translate("MasterFrame", "Color124", nullptr));
        pushButtonColor97->setText(QApplication::translate("MasterFrame", "Color97", nullptr));
        pushButtonColor126->setText(QApplication::translate("MasterFrame", "Color126", nullptr));
        pushButtonColor115->setText(QApplication::translate("MasterFrame", "Color115", nullptr));
        pushButtonColor129->setText(QApplication::translate("MasterFrame", "Color129", nullptr));
        pushButtonColor131->setText(QApplication::translate("MasterFrame", "Color131", nullptr));
        pushButtonColor127->setText(QApplication::translate("MasterFrame", "Color127", nullptr));
        pushButtonColor135->setText(QApplication::translate("MasterFrame", "Color135", nullptr));
        pushButtonColor93->setText(QApplication::translate("MasterFrame", "Color93", nullptr));
        pushButtonColor103->setText(QApplication::translate("MasterFrame", "Color103", nullptr));
        pushButtonColor98->setText(QApplication::translate("MasterFrame", "Color98", nullptr));
        pushButtonColor111->setText(QApplication::translate("MasterFrame", "Color111", nullptr));
        pushButtonColor102->setText(QApplication::translate("MasterFrame", "Color102", nullptr));
        pushButtonColor114->setText(QApplication::translate("MasterFrame", "Color114", nullptr));
        pushButtonColor110->setText(QApplication::translate("MasterFrame", "Color110", nullptr));
        pushButtonColor118->setText(QApplication::translate("MasterFrame", "Color118", nullptr));
        pushButtonColor116->setText(QApplication::translate("MasterFrame", "Color116", nullptr));
        pushButtonColor100->setText(QApplication::translate("MasterFrame", "Color100", nullptr));
        pushButtonColor134->setText(QApplication::translate("MasterFrame", "Color134", nullptr));
        pushButtonColor125->setText(QApplication::translate("MasterFrame", "Color125", nullptr));
        pushButtonColor91->setText(QApplication::translate("MasterFrame", "Color91", nullptr));
        pushButtonColor109->setText(QApplication::translate("MasterFrame", "Color109", nullptr));
        pushButtonColor96->setText(QApplication::translate("MasterFrame", "Color96", nullptr));
        pushButtonColor113->setText(QApplication::translate("MasterFrame", "Color113", nullptr));
        pushButtonColor106->setText(QApplication::translate("MasterFrame", "Color106", nullptr));
        pushButtonColor107->setText(QApplication::translate("MasterFrame", "Color107", nullptr));
        pushButtonColor95->setText(QApplication::translate("MasterFrame", "Color95", nullptr));
        pushButtonColor101->setText(QApplication::translate("MasterFrame", "Color101", nullptr));
        pushButtonColor119->setText(QApplication::translate("MasterFrame", "Color119", nullptr));
        pushButtonColor123->setText(QApplication::translate("MasterFrame", "Color123", nullptr));
        pushButtonColor133->setText(QApplication::translate("MasterFrame", "Color133", nullptr));
        pushButtonColor122->setText(QApplication::translate("MasterFrame", "Color122", nullptr));
        pushButtonColor92->setText(QApplication::translate("MasterFrame", "Color92", nullptr));
        groupBox_4->setTitle(QApplication::translate("MasterFrame", "Color Table:", nullptr));
        pushButtonColor161->setText(QApplication::translate("MasterFrame", "Color161", nullptr));
        pushButtonColor166->setText(QApplication::translate("MasterFrame", "Color166", nullptr));
        pushButtonColor167->setText(QApplication::translate("MasterFrame", "Color167", nullptr));
        pushButtonColor155->setText(QApplication::translate("MasterFrame", "Color155", nullptr));
        pushButtonColor138->setText(QApplication::translate("MasterFrame", "Color138", nullptr));
        pushButtonColor156->setText(QApplication::translate("MasterFrame", "Color156", nullptr));
        pushButtonColor153->setText(QApplication::translate("MasterFrame", "Color153", nullptr));
        pushButtonColor165->setText(QApplication::translate("MasterFrame", "Color165", nullptr));
        pushButtonColor170->setText(QApplication::translate("MasterFrame", "Color170", nullptr));
        pushButtonColor157->setText(QApplication::translate("MasterFrame", "Color157", nullptr));
        pushButtonColor150->setText(QApplication::translate("MasterFrame", "Color150", nullptr));
        pushButtonColor145->setText(QApplication::translate("MasterFrame", "Color145", nullptr));
        pushButtonColor137->setText(QApplication::translate("MasterFrame", "Color137", nullptr));
        pushButtonColor179->setText(QApplication::translate("MasterFrame", "Color179", nullptr));
        pushButtonColor146->setText(QApplication::translate("MasterFrame", "Color146", nullptr));
        pushButtonColor180->setText(QApplication::translate("MasterFrame", "Color180", nullptr));
        pushButtonColor164->setText(QApplication::translate("MasterFrame", "Color164", nullptr));
        pushButtonColor144->setText(QApplication::translate("MasterFrame", "Color144", nullptr));
        pushButtonColor151->setText(QApplication::translate("MasterFrame", "Color151", nullptr));
        pushButtonColor160->setText(QApplication::translate("MasterFrame", "Color160", nullptr));
        pushButtonColor175->setText(QApplication::translate("MasterFrame", "Color175", nullptr));
        pushButtonColor169->setText(QApplication::translate("MasterFrame", "Color169", nullptr));
        pushButtonColor140->setText(QApplication::translate("MasterFrame", "Color140", nullptr));
        pushButtonColor159->setText(QApplication::translate("MasterFrame", "Color159", nullptr));
        pushButtonColor163->setText(QApplication::translate("MasterFrame", "Color163", nullptr));
        pushButtonColor143->setText(QApplication::translate("MasterFrame", "Color143", nullptr));
        pushButtonColor177->setText(QApplication::translate("MasterFrame", "Color177", nullptr));
        pushButtonColor158->setText(QApplication::translate("MasterFrame", "Color158", nullptr));
        pushButtonColor149->setText(QApplication::translate("MasterFrame", "Color149", nullptr));
        pushButtonColor136->setText(QApplication::translate("MasterFrame", "Color136", nullptr));
        pushButtonColor178->setText(QApplication::translate("MasterFrame", "Color178", nullptr));
        pushButtonColor171->setText(QApplication::translate("MasterFrame", "Color171", nullptr));
        pushButtonColor154->setText(QApplication::translate("MasterFrame", "Color154", nullptr));
        pushButtonColor172->setText(QApplication::translate("MasterFrame", "Color172", nullptr));
        pushButtonColor168->setText(QApplication::translate("MasterFrame", "Color168", nullptr));
        pushButtonColor142->setText(QApplication::translate("MasterFrame", "Color142", nullptr));
        pushButtonColor152->setText(QApplication::translate("MasterFrame", "Color152", nullptr));
        pushButtonColor162->setText(QApplication::translate("MasterFrame", "Color162", nullptr));
        pushButtonColor141->setText(QApplication::translate("MasterFrame", "Color141", nullptr));
        pushButtonColor176->setText(QApplication::translate("MasterFrame", "Color176", nullptr));
        pushButtonColor148->setText(QApplication::translate("MasterFrame", "Color148", nullptr));
        pushButtonColor174->setText(QApplication::translate("MasterFrame", "Color174", nullptr));
        pushButtonColor147->setText(QApplication::translate("MasterFrame", "Color147", nullptr));
        pushButtonColor139->setText(QApplication::translate("MasterFrame", "Color139", nullptr));
        pushButtonColor173->setText(QApplication::translate("MasterFrame", "Color173", nullptr));
        groupBox_6->setTitle(QApplication::translate("MasterFrame", "Color Table:", nullptr));
        pushButtonColor229->setText(QApplication::translate("MasterFrame", "Color229", nullptr));
        pushButtonColor248->setText(QApplication::translate("MasterFrame", "Color248", nullptr));
        pushButtonColor256->setText(QApplication::translate("MasterFrame", "Color256", nullptr));
        pushButtonColor226->setText(QApplication::translate("MasterFrame", "Color226", nullptr));
        pushButtonColor234->setText(QApplication::translate("MasterFrame", "Color234", nullptr));
        pushButtonColor244->setText(QApplication::translate("MasterFrame", "Color244", nullptr));
        pushButtonColor243->setText(QApplication::translate("MasterFrame", "Color243", nullptr));
        pushButtonColor255->setText(QApplication::translate("MasterFrame", "Color255", nullptr));
        pushButtonColor240->setText(QApplication::translate("MasterFrame", "Color240", nullptr));
        pushButtonColor233->setText(QApplication::translate("MasterFrame", "Color233", nullptr));
        pushButtonColor232->setText(QApplication::translate("MasterFrame", "Color232", nullptr));
        pushButtonColor228->setText(QApplication::translate("MasterFrame", "Color228", nullptr));
        pushButtonColor237->setText(QApplication::translate("MasterFrame", "Color237", nullptr));
        pushButtonColor245->setText(QApplication::translate("MasterFrame", "Color245", nullptr));
        pushButtonColor239->setText(QApplication::translate("MasterFrame", "Color239", nullptr));
        pushButtonColor242->setText(QApplication::translate("MasterFrame", "Color242", nullptr));
        pushButtonColor230->setText(QApplication::translate("MasterFrame", "Color230", nullptr));
        pushButtonColor241->setText(QApplication::translate("MasterFrame", "Color241", nullptr));
        pushButtonColor231->setText(QApplication::translate("MasterFrame", "Color231", nullptr));
        pushButtonColor238->setText(QApplication::translate("MasterFrame", "Color238", nullptr));
        pushButtonColor249->setText(QApplication::translate("MasterFrame", "Color249", nullptr));
        pushButtonColor227->setText(QApplication::translate("MasterFrame", "Color227", nullptr));
        pushButtonColor250->setText(QApplication::translate("MasterFrame", "Color250", nullptr));
        pushButtonColor236->setText(QApplication::translate("MasterFrame", "Color236", nullptr));
        pushButtonColor252->setText(QApplication::translate("MasterFrame", "Color252", nullptr));
        pushButtonColor246->setText(QApplication::translate("MasterFrame", "Color246", nullptr));
        pushButtonColor251->setText(QApplication::translate("MasterFrame", "Color251", nullptr));
        pushButtonColor254->setText(QApplication::translate("MasterFrame", "Color254", nullptr));
        pushButtonColor235->setText(QApplication::translate("MasterFrame", "Color235", nullptr));
        pushButtonColor253->setText(QApplication::translate("MasterFrame", "Color253", nullptr));
        pushButtonColor247->setText(QApplication::translate("MasterFrame", "Color247", nullptr));
        groupBox_2->setTitle(QApplication::translate("MasterFrame", "Color Table:", nullptr));
        pushButtonColor75->setText(QApplication::translate("MasterFrame", "Color75", nullptr));
        pushButtonColor55->setText(QApplication::translate("MasterFrame", "Color55", nullptr));
        pushButtonColor85->setText(QApplication::translate("MasterFrame", "Color85", nullptr));
        pushButtonColor73->setText(QApplication::translate("MasterFrame", "Color73", nullptr));
        pushButtonColor46->setText(QApplication::translate("MasterFrame", "Color46", nullptr));
        pushButtonColor83->setText(QApplication::translate("MasterFrame", "Color83", nullptr));
        pushButtonColor66->setText(QApplication::translate("MasterFrame", "Color66", nullptr));
        pushButtonColor81->setText(QApplication::translate("MasterFrame", "Color81", nullptr));
        pushButtonColor50->setText(QApplication::translate("MasterFrame", "Color50", nullptr));
        pushButtonColor74->setText(QApplication::translate("MasterFrame", "Color74", nullptr));
        pushButtonColor56->setText(QApplication::translate("MasterFrame", "Color56", nullptr));
        pushButtonColor71->setText(QApplication::translate("MasterFrame", "Color71", nullptr));
        pushButtonColor72->setText(QApplication::translate("MasterFrame", "Color72", nullptr));
        pushButtonColor67->setText(QApplication::translate("MasterFrame", "Color67", nullptr));
        pushButtonColor89->setText(QApplication::translate("MasterFrame", "Color89", nullptr));
        pushButtonColor60->setText(QApplication::translate("MasterFrame", "Color60", nullptr));
        pushButtonColor87->setText(QApplication::translate("MasterFrame", "Color87", nullptr));
        pushButtonColor61->setText(QApplication::translate("MasterFrame", "Color61", nullptr));
        pushButtonColor63->setText(QApplication::translate("MasterFrame", "Color63", nullptr));
        pushButtonColor51->setText(QApplication::translate("MasterFrame", "Color51", nullptr));
        pushButtonColor80->setText(QApplication::translate("MasterFrame", "Color80", nullptr));
        pushButtonColor48->setText(QApplication::translate("MasterFrame", "Color48", nullptr));
        pushButtonColor76->setText(QApplication::translate("MasterFrame", "Color76", nullptr));
        pushButtonColor69->setText(QApplication::translate("MasterFrame", "Color69", nullptr));
        pushButtonColor54->setText(QApplication::translate("MasterFrame", "Color54", nullptr));
        pushButtonColor64->setText(QApplication::translate("MasterFrame", "Color64", nullptr));
        pushButtonColor57->setText(QApplication::translate("MasterFrame", "Color57", nullptr));
        pushButtonColor88->setText(QApplication::translate("MasterFrame", "Color88", nullptr));
        pushButtonColor70->setText(QApplication::translate("MasterFrame", "Color70", nullptr));
        pushButtonColor68->setText(QApplication::translate("MasterFrame", "Color68", nullptr));
        pushButtonColor49->setText(QApplication::translate("MasterFrame", "Color49", nullptr));
        pushButtonColor86->setText(QApplication::translate("MasterFrame", "Color86", nullptr));
        pushButtonColor78->setText(QApplication::translate("MasterFrame", "Color78", nullptr));
        pushButtonColor84->setText(QApplication::translate("MasterFrame", "Color84", nullptr));
        pushButtonColor90->setText(QApplication::translate("MasterFrame", "Color90", nullptr));
        pushButtonColor62->setText(QApplication::translate("MasterFrame", "Color62", nullptr));
        pushButtonColor79->setText(QApplication::translate("MasterFrame", "Color79", nullptr));
        pushButtonColor53->setText(QApplication::translate("MasterFrame", "Color53", nullptr));
        pushButtonColor82->setText(QApplication::translate("MasterFrame", "Color82", nullptr));
        pushButtonColor59->setText(QApplication::translate("MasterFrame", "Color59", nullptr));
        pushButtonColor77->setText(QApplication::translate("MasterFrame", "Color77", nullptr));
        pushButtonColor52->setText(QApplication::translate("MasterFrame", "Color52", nullptr));
        pushButtonColor65->setText(QApplication::translate("MasterFrame", "Color65", nullptr));
        pushButtonColor47->setText(QApplication::translate("MasterFrame", "Color47", nullptr));
        pushButtonColor58->setText(QApplication::translate("MasterFrame", "Color58", nullptr));
        groupBox->setTitle(QApplication::translate("MasterFrame", "Color Table:", nullptr));
        pushButtonColor12->setText(QApplication::translate("MasterFrame", "Color12", nullptr));
        pushButtonColor39->setText(QApplication::translate("MasterFrame", "Color39", nullptr));
        pushButtonColor1->setText(QApplication::translate("MasterFrame", "Color1", nullptr));
        pushButtonColor38->setText(QApplication::translate("MasterFrame", "Color38", nullptr));
        pushButtonColor27->setText(QApplication::translate("MasterFrame", "Color27", nullptr));
        pushButtonColor41->setText(QApplication::translate("MasterFrame", "Color41", nullptr));
        pushButtonColor2->setText(QApplication::translate("MasterFrame", "Color2", nullptr));
        pushButtonColor28->setText(QApplication::translate("MasterFrame", "Color28", nullptr));
        pushButtonColor45->setText(QApplication::translate("MasterFrame", "Color45", nullptr));
        pushButtonColor32->setText(QApplication::translate("MasterFrame", "Color32", nullptr));
        pushButtonColor13->setText(QApplication::translate("MasterFrame", "Color13", nullptr));
        pushButtonColor24->setText(QApplication::translate("MasterFrame", "Color24", nullptr));
        pushButtonColor19->setText(QApplication::translate("MasterFrame", "Color19", nullptr));
        pushButtonColor42->setText(QApplication::translate("MasterFrame", "Color42", nullptr));
        pushButtonColor7->setText(QApplication::translate("MasterFrame", "Color7", nullptr));
        pushButtonColor37->setText(QApplication::translate("MasterFrame", "Color37", nullptr));
        pushButtonColor10->setText(QApplication::translate("MasterFrame", "Color10", nullptr));
        pushButtonColor25->setText(QApplication::translate("MasterFrame", "Color25", nullptr));
        pushButtonColor6->setText(QApplication::translate("MasterFrame", "Color6", nullptr));
        pushButtonColor29->setText(QApplication::translate("MasterFrame", "Color29", nullptr));
        pushButtonColor22->setText(QApplication::translate("MasterFrame", "Color22", nullptr));
        pushButtonColor44->setText(QApplication::translate("MasterFrame", "Color44", nullptr));
        pushButtonColor20->setText(QApplication::translate("MasterFrame", "Color20", nullptr));
        pushButtonColor14->setText(QApplication::translate("MasterFrame", "Color14", nullptr));
        pushButtonColor43->setText(QApplication::translate("MasterFrame", "Color43", nullptr));
        pushButtonColor8->setText(QApplication::translate("MasterFrame", "Color8", nullptr));
        pushButtonColor36->setText(QApplication::translate("MasterFrame", "Color36", nullptr));
        pushButtonColor4->setText(QApplication::translate("MasterFrame", "Color4", nullptr));
        pushButtonColor40->setText(QApplication::translate("MasterFrame", "Color40", nullptr));
        pushButtonColor33->setText(QApplication::translate("MasterFrame", "Color33", nullptr));
        pushButtonColor18->setText(QApplication::translate("MasterFrame", "Color18", nullptr));
        pushButtonColor30->setText(QApplication::translate("MasterFrame", "Color30", nullptr));
        pushButtonColor21->setText(QApplication::translate("MasterFrame", "Color21", nullptr));
        pushButtonColor26->setText(QApplication::translate("MasterFrame", "Color26", nullptr));
        pushButtonColor34->setText(QApplication::translate("MasterFrame", "Color34", nullptr));
        pushButtonColor23->setText(QApplication::translate("MasterFrame", "Color23", nullptr));
        pushButtonColor5->setText(QApplication::translate("MasterFrame", "Color5", nullptr));
        pushButtonColor17->setText(QApplication::translate("MasterFrame", "Color17", nullptr));
        pushButtonColor3->setText(QApplication::translate("MasterFrame", "Color3", nullptr));
        pushButtonColor11->setText(QApplication::translate("MasterFrame", "Color11", nullptr));
        pushButtonColor16->setText(QApplication::translate("MasterFrame", "Color16", nullptr));
        pushButtonColor31->setText(QApplication::translate("MasterFrame", "Color31", nullptr));
        pushButtonColor35->setText(QApplication::translate("MasterFrame", "Color35", nullptr));
        pushButtonColor15->setText(QApplication::translate("MasterFrame", "Color15", nullptr));
        pushButtonColor9->setText(QApplication::translate("MasterFrame", "Color9", nullptr));
        pushButtoncheck_mode->setText(QApplication::translate("MasterFrame", "check mode\n"
"off", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MasterFrame: public Ui_MasterFrame {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MASTERFRAME_H
