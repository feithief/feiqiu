/********************************************************************************
** Form generated from reading UI file 'amkeyboard.ui'
**
** Created by: Qt User Interface Compiler version 5.10.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_AMKEYBOARD_H
#define UI_AMKEYBOARD_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_AMKeyboard
{
public:
    QPushButton *pushButtonQ;
    QPushButton *pushButtonA;
    QPushButton *pushButtonZ;
    QPushButton *pushButtonSPACE;
    QPushButton *pushButtonX;
    QPushButton *pushButtonS;
    QPushButton *pushButtonW;
    QPushButton *pushButtonC;
    QPushButton *pushButtonD;
    QPushButton *pushButtonE;
    QPushButton *pushButtonV;
    QPushButton *pushButtonF;
    QPushButton *pushButtonR;
    QPushButton *pushButtonB;
    QPushButton *pushButtonG;
    QPushButton *pushButtonT;
    QPushButton *pushButtonN;
    QPushButton *pushButtonH;
    QPushButton *pushButtonY;
    QPushButton *pushButtonM;
    QPushButton *pushButtonJ;
    QPushButton *pushButtonU;
    QPushButton *pushButtonSEP;
    QPushButton *pushButtonI;
    QPushButton *pushButtonK;
    QPushButton *pushButtonORR;
    QPushButton *pushButtonO;
    QPushButton *pushButtonL;
    QPushButton *pushButtonP;
    QPushButton *pushButtonDOLLAR;
    QPushButton *pushButtonBACKSPACE;
    QPushButton *pushButtonSHARP;
    QPushButton *pushButtonDIV;
    QPushButton *pushButtonMUTIPLY;
    QPushButton *pushButtonRIGHT;
    QPushButton *pushButtonLEFT;
    QPushButton *pushButton9;
    QPushButton *pushButton1;
    QPushButton *pushButton2;
    QPushButton *pushButton8;
    QPushButton *pushButton6;
    QPushButton *pushButton7;
    QPushButton *pushButton4;
    QPushButton *pushButton3;
    QPushButton *pushButton5;
    QPushButton *pushButtonDOT;
    QPushButton *pushButton0;
    QPushButton *pushButtonMINUS;
    QPushButton *pushButtonOK;
    QPushButton *pushButtonPLUS;

    void setupUi(QWidget *AMKeyboard)
    {
        if (AMKeyboard->objectName().isEmpty())
            AMKeyboard->setObjectName(QStringLiteral("AMKeyboard"));
        AMKeyboard->resize(1230, 353);
        pushButtonQ = new QPushButton(AMKeyboard);
        pushButtonQ->setObjectName(QStringLiteral("pushButtonQ"));
        pushButtonQ->setGeometry(QRect(20, 20, 68, 68));
        pushButtonQ->setFocusPolicy(Qt::NoFocus);
        pushButtonQ->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-radius: 10px;\n"
"color:rgb(255,251,240);\n"
"font-size:28px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonA = new QPushButton(AMKeyboard);
        pushButtonA->setObjectName(QStringLiteral("pushButtonA"));
        pushButtonA->setGeometry(QRect(20, 100, 68, 68));
        pushButtonA->setFocusPolicy(Qt::NoFocus);
        pushButtonA->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-radius: 10px;\n"
"color:rgb(255,251,240);\n"
"font-size:28px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonZ = new QPushButton(AMKeyboard);
        pushButtonZ->setObjectName(QStringLiteral("pushButtonZ"));
        pushButtonZ->setGeometry(QRect(20, 180, 68, 68));
        pushButtonZ->setFocusPolicy(Qt::NoFocus);
        pushButtonZ->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-radius: 10px;\n"
"color:rgb(255,251,240);\n"
"font-size:28px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonSPACE = new QPushButton(AMKeyboard);
        pushButtonSPACE->setObjectName(QStringLiteral("pushButtonSPACE"));
        pushButtonSPACE->setGeometry(QRect(20, 259, 788, 68));
        pushButtonSPACE->setFocusPolicy(Qt::NoFocus);
        pushButtonSPACE->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-radius: 10px;\n"
"color:rgb(255,251,240);\n"
"font-size:28px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonX = new QPushButton(AMKeyboard);
        pushButtonX->setObjectName(QStringLiteral("pushButtonX"));
        pushButtonX->setGeometry(QRect(100, 180, 68, 68));
        pushButtonX->setFocusPolicy(Qt::NoFocus);
        pushButtonX->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-radius: 10px;\n"
"color:rgb(255,251,240);\n"
"font-size:28px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonS = new QPushButton(AMKeyboard);
        pushButtonS->setObjectName(QStringLiteral("pushButtonS"));
        pushButtonS->setGeometry(QRect(100, 100, 68, 68));
        pushButtonS->setFocusPolicy(Qt::NoFocus);
        pushButtonS->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-radius: 10px;\n"
"color:rgb(255,251,240);\n"
"font-size:28px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonW = new QPushButton(AMKeyboard);
        pushButtonW->setObjectName(QStringLiteral("pushButtonW"));
        pushButtonW->setGeometry(QRect(100, 20, 68, 68));
        pushButtonW->setFocusPolicy(Qt::NoFocus);
        pushButtonW->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-radius: 10px;\n"
"color:rgb(255,251,240);\n"
"font-size:28px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonC = new QPushButton(AMKeyboard);
        pushButtonC->setObjectName(QStringLiteral("pushButtonC"));
        pushButtonC->setGeometry(QRect(180, 180, 68, 68));
        pushButtonC->setFocusPolicy(Qt::NoFocus);
        pushButtonC->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-radius: 10px;\n"
"color:rgb(255,251,240);\n"
"font-size:28px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonD = new QPushButton(AMKeyboard);
        pushButtonD->setObjectName(QStringLiteral("pushButtonD"));
        pushButtonD->setGeometry(QRect(180, 100, 68, 68));
        pushButtonD->setFocusPolicy(Qt::NoFocus);
        pushButtonD->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-radius: 10px;\n"
"color:rgb(255,251,240);\n"
"font-size:28px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonE = new QPushButton(AMKeyboard);
        pushButtonE->setObjectName(QStringLiteral("pushButtonE"));
        pushButtonE->setGeometry(QRect(180, 20, 68, 68));
        pushButtonE->setFocusPolicy(Qt::NoFocus);
        pushButtonE->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-radius: 10px;\n"
"color:rgb(255,251,240);\n"
"font-size:28px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonV = new QPushButton(AMKeyboard);
        pushButtonV->setObjectName(QStringLiteral("pushButtonV"));
        pushButtonV->setGeometry(QRect(260, 180, 68, 68));
        pushButtonV->setFocusPolicy(Qt::NoFocus);
        pushButtonV->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-radius: 10px;\n"
"color:rgb(255,251,240);\n"
"font-size:28px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonF = new QPushButton(AMKeyboard);
        pushButtonF->setObjectName(QStringLiteral("pushButtonF"));
        pushButtonF->setGeometry(QRect(260, 100, 68, 68));
        pushButtonF->setFocusPolicy(Qt::NoFocus);
        pushButtonF->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-radius: 10px;\n"
"color:rgb(255,251,240);\n"
"font-size:28px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonR = new QPushButton(AMKeyboard);
        pushButtonR->setObjectName(QStringLiteral("pushButtonR"));
        pushButtonR->setGeometry(QRect(260, 20, 68, 68));
        pushButtonR->setFocusPolicy(Qt::NoFocus);
        pushButtonR->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-radius: 10px;\n"
"color:rgb(255,251,240);\n"
"font-size:28px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonB = new QPushButton(AMKeyboard);
        pushButtonB->setObjectName(QStringLiteral("pushButtonB"));
        pushButtonB->setGeometry(QRect(340, 180, 68, 68));
        pushButtonB->setFocusPolicy(Qt::NoFocus);
        pushButtonB->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-radius: 10px;\n"
"color:rgb(255,251,240);\n"
"font-size:28px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonG = new QPushButton(AMKeyboard);
        pushButtonG->setObjectName(QStringLiteral("pushButtonG"));
        pushButtonG->setGeometry(QRect(340, 100, 68, 68));
        pushButtonG->setFocusPolicy(Qt::NoFocus);
        pushButtonG->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-radius: 10px;\n"
"color:rgb(255,251,240);\n"
"font-size:28px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonT = new QPushButton(AMKeyboard);
        pushButtonT->setObjectName(QStringLiteral("pushButtonT"));
        pushButtonT->setGeometry(QRect(340, 20, 68, 68));
        pushButtonT->setFocusPolicy(Qt::NoFocus);
        pushButtonT->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-radius: 10px;\n"
"color:rgb(255,251,240);\n"
"font-size:28px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonN = new QPushButton(AMKeyboard);
        pushButtonN->setObjectName(QStringLiteral("pushButtonN"));
        pushButtonN->setGeometry(QRect(420, 180, 68, 68));
        pushButtonN->setFocusPolicy(Qt::NoFocus);
        pushButtonN->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-radius: 10px;\n"
"color:rgb(255,251,240);\n"
"font-size:28px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonH = new QPushButton(AMKeyboard);
        pushButtonH->setObjectName(QStringLiteral("pushButtonH"));
        pushButtonH->setGeometry(QRect(420, 100, 68, 68));
        pushButtonH->setFocusPolicy(Qt::NoFocus);
        pushButtonH->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-radius: 10px;\n"
"color:rgb(255,251,240);\n"
"font-size:28px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonY = new QPushButton(AMKeyboard);
        pushButtonY->setObjectName(QStringLiteral("pushButtonY"));
        pushButtonY->setGeometry(QRect(420, 20, 68, 68));
        pushButtonY->setFocusPolicy(Qt::NoFocus);
        pushButtonY->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-radius: 10px;\n"
"color:rgb(255,251,240);\n"
"font-size:28px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonM = new QPushButton(AMKeyboard);
        pushButtonM->setObjectName(QStringLiteral("pushButtonM"));
        pushButtonM->setGeometry(QRect(500, 180, 68, 68));
        pushButtonM->setFocusPolicy(Qt::NoFocus);
        pushButtonM->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-radius: 10px;\n"
"color:rgb(255,251,240);\n"
"font-size:28px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonJ = new QPushButton(AMKeyboard);
        pushButtonJ->setObjectName(QStringLiteral("pushButtonJ"));
        pushButtonJ->setGeometry(QRect(500, 100, 68, 68));
        pushButtonJ->setFocusPolicy(Qt::NoFocus);
        pushButtonJ->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-radius: 10px;\n"
"color:rgb(255,251,240);\n"
"font-size:28px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonU = new QPushButton(AMKeyboard);
        pushButtonU->setObjectName(QStringLiteral("pushButtonU"));
        pushButtonU->setGeometry(QRect(500, 20, 68, 68));
        pushButtonU->setFocusPolicy(Qt::NoFocus);
        pushButtonU->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-radius: 10px;\n"
"color:rgb(255,251,240);\n"
"font-size:28px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonSEP = new QPushButton(AMKeyboard);
        pushButtonSEP->setObjectName(QStringLiteral("pushButtonSEP"));
        pushButtonSEP->setGeometry(QRect(580, 180, 68, 68));
        pushButtonSEP->setFocusPolicy(Qt::NoFocus);
        pushButtonSEP->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-radius: 10px;\n"
"color:rgb(255,251,240);\n"
"font-size:28px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonI = new QPushButton(AMKeyboard);
        pushButtonI->setObjectName(QStringLiteral("pushButtonI"));
        pushButtonI->setGeometry(QRect(580, 20, 68, 68));
        pushButtonI->setFocusPolicy(Qt::NoFocus);
        pushButtonI->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-radius: 10px;\n"
"color:rgb(255,251,240);\n"
"font-size:28px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonK = new QPushButton(AMKeyboard);
        pushButtonK->setObjectName(QStringLiteral("pushButtonK"));
        pushButtonK->setGeometry(QRect(580, 100, 68, 68));
        pushButtonK->setFocusPolicy(Qt::NoFocus);
        pushButtonK->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-radius: 10px;\n"
"color:rgb(255,251,240);\n"
"font-size:28px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonORR = new QPushButton(AMKeyboard);
        pushButtonORR->setObjectName(QStringLiteral("pushButtonORR"));
        pushButtonORR->setGeometry(QRect(660, 180, 68, 68));
        pushButtonORR->setFocusPolicy(Qt::NoFocus);
        pushButtonORR->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-radius: 10px;\n"
"color:rgb(255,251,240);\n"
"font-size:28px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonO = new QPushButton(AMKeyboard);
        pushButtonO->setObjectName(QStringLiteral("pushButtonO"));
        pushButtonO->setGeometry(QRect(660, 20, 68, 68));
        pushButtonO->setFocusPolicy(Qt::NoFocus);
        pushButtonO->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-radius: 10px;\n"
"color:rgb(255,251,240);\n"
"font-size:28px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonL = new QPushButton(AMKeyboard);
        pushButtonL->setObjectName(QStringLiteral("pushButtonL"));
        pushButtonL->setGeometry(QRect(660, 100, 68, 68));
        pushButtonL->setFocusPolicy(Qt::NoFocus);
        pushButtonL->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-radius: 10px;\n"
"color:rgb(255,251,240);\n"
"font-size:28px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonP = new QPushButton(AMKeyboard);
        pushButtonP->setObjectName(QStringLiteral("pushButtonP"));
        pushButtonP->setGeometry(QRect(740, 20, 68, 68));
        pushButtonP->setFocusPolicy(Qt::NoFocus);
        pushButtonP->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-radius: 10px;\n"
"color:rgb(255,251,240);\n"
"font-size:28px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonDOLLAR = new QPushButton(AMKeyboard);
        pushButtonDOLLAR->setObjectName(QStringLiteral("pushButtonDOLLAR"));
        pushButtonDOLLAR->setGeometry(QRect(740, 180, 68, 68));
        pushButtonDOLLAR->setFocusPolicy(Qt::NoFocus);
        pushButtonDOLLAR->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-radius: 10px;\n"
"color:rgb(255,251,240);\n"
"font-size:28px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonBACKSPACE = new QPushButton(AMKeyboard);
        pushButtonBACKSPACE->setObjectName(QStringLiteral("pushButtonBACKSPACE"));
        pushButtonBACKSPACE->setGeometry(QRect(820, 20, 71, 68));
        pushButtonBACKSPACE->setFocusPolicy(Qt::NoFocus);
        pushButtonBACKSPACE->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-radius: 10px;\n"
"color:rgb(255,251,240);\n"
"font-size:28px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonSHARP = new QPushButton(AMKeyboard);
        pushButtonSHARP->setObjectName(QStringLiteral("pushButtonSHARP"));
        pushButtonSHARP->setGeometry(QRect(740, 100, 68, 68));
        pushButtonSHARP->setFocusPolicy(Qt::NoFocus);
        pushButtonSHARP->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-radius: 10px;\n"
"color:rgb(255,251,240);\n"
"font-size:28px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonDIV = new QPushButton(AMKeyboard);
        pushButtonDIV->setObjectName(QStringLiteral("pushButtonDIV"));
        pushButtonDIV->setGeometry(QRect(820, 180, 68, 68));
        pushButtonDIV->setFocusPolicy(Qt::NoFocus);
        pushButtonDIV->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-radius: 10px;\n"
"color:rgb(255,251,240);\n"
"font-size:28px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonMUTIPLY = new QPushButton(AMKeyboard);
        pushButtonMUTIPLY->setObjectName(QStringLiteral("pushButtonMUTIPLY"));
        pushButtonMUTIPLY->setGeometry(QRect(820, 100, 68, 68));
        pushButtonMUTIPLY->setFocusPolicy(Qt::NoFocus);
        pushButtonMUTIPLY->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-radius: 10px;\n"
"color:rgb(255,251,240);\n"
"font-size:28px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonRIGHT = new QPushButton(AMKeyboard);
        pushButtonRIGHT->setObjectName(QStringLiteral("pushButtonRIGHT"));
        pushButtonRIGHT->setGeometry(QRect(900, 260, 68, 68));
        pushButtonRIGHT->setFocusPolicy(Qt::NoFocus);
        pushButtonRIGHT->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-radius: 10px;\n"
"color:rgb(255,251,240);\n"
"font-size:28px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonLEFT = new QPushButton(AMKeyboard);
        pushButtonLEFT->setObjectName(QStringLiteral("pushButtonLEFT"));
        pushButtonLEFT->setGeometry(QRect(820, 260, 68, 68));
        pushButtonLEFT->setFocusPolicy(Qt::NoFocus);
        pushButtonLEFT->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-radius: 10px;\n"
"color:rgb(255,251,240);\n"
"font-size:28px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButton9 = new QPushButton(AMKeyboard);
        pushButton9->setObjectName(QStringLiteral("pushButton9"));
        pushButton9->setGeometry(QRect(1060, 20, 68, 68));
        pushButton9->setFocusPolicy(Qt::NoFocus);
        pushButton9->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-radius: 10px;\n"
"color:rgb(255,251,240);\n"
"font-size:28px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButton1 = new QPushButton(AMKeyboard);
        pushButton1->setObjectName(QStringLiteral("pushButton1"));
        pushButton1->setGeometry(QRect(900, 180, 68, 68));
        pushButton1->setFocusPolicy(Qt::NoFocus);
        pushButton1->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-radius: 10px;\n"
"color:rgb(255,251,240);\n"
"font-size:28px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButton2 = new QPushButton(AMKeyboard);
        pushButton2->setObjectName(QStringLiteral("pushButton2"));
        pushButton2->setGeometry(QRect(980, 180, 68, 68));
        pushButton2->setFocusPolicy(Qt::NoFocus);
        pushButton2->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-radius: 10px;\n"
"color:rgb(255,251,240);\n"
"font-size:28px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButton8 = new QPushButton(AMKeyboard);
        pushButton8->setObjectName(QStringLiteral("pushButton8"));
        pushButton8->setGeometry(QRect(980, 20, 68, 68));
        pushButton8->setFocusPolicy(Qt::NoFocus);
        pushButton8->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-radius: 10px;\n"
"color:rgb(255,251,240);\n"
"font-size:28px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButton6 = new QPushButton(AMKeyboard);
        pushButton6->setObjectName(QStringLiteral("pushButton6"));
        pushButton6->setGeometry(QRect(1060, 100, 68, 68));
        pushButton6->setFocusPolicy(Qt::NoFocus);
        pushButton6->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-radius: 10px;\n"
"color:rgb(255,251,240);\n"
"font-size:28px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButton7 = new QPushButton(AMKeyboard);
        pushButton7->setObjectName(QStringLiteral("pushButton7"));
        pushButton7->setGeometry(QRect(900, 20, 68, 68));
        pushButton7->setFocusPolicy(Qt::NoFocus);
        pushButton7->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-radius: 10px;\n"
"color:rgb(255,251,240);\n"
"font-size:28px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButton4 = new QPushButton(AMKeyboard);
        pushButton4->setObjectName(QStringLiteral("pushButton4"));
        pushButton4->setGeometry(QRect(900, 100, 68, 68));
        pushButton4->setFocusPolicy(Qt::NoFocus);
        pushButton4->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-radius: 10px;\n"
"color:rgb(255,251,240);\n"
"font-size:28px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButton3 = new QPushButton(AMKeyboard);
        pushButton3->setObjectName(QStringLiteral("pushButton3"));
        pushButton3->setGeometry(QRect(1060, 180, 68, 68));
        pushButton3->setFocusPolicy(Qt::NoFocus);
        pushButton3->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-radius: 10px;\n"
"color:rgb(255,251,240);\n"
"font-size:28px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButton5 = new QPushButton(AMKeyboard);
        pushButton5->setObjectName(QStringLiteral("pushButton5"));
        pushButton5->setGeometry(QRect(980, 100, 68, 68));
        pushButton5->setFocusPolicy(Qt::NoFocus);
        pushButton5->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-radius: 10px;\n"
"color:rgb(255,251,240);\n"
"font-size:28px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonDOT = new QPushButton(AMKeyboard);
        pushButtonDOT->setObjectName(QStringLiteral("pushButtonDOT"));
        pushButtonDOT->setGeometry(QRect(1060, 260, 68, 68));
        pushButtonDOT->setFocusPolicy(Qt::NoFocus);
        pushButtonDOT->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-radius: 10px;\n"
"color:rgb(255,251,240);\n"
"font-size:28px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButton0 = new QPushButton(AMKeyboard);
        pushButton0->setObjectName(QStringLiteral("pushButton0"));
        pushButton0->setGeometry(QRect(980, 260, 68, 68));
        pushButton0->setFocusPolicy(Qt::NoFocus);
        pushButton0->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-radius: 10px;\n"
"color:rgb(255,251,240);\n"
"font-size:28px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonMINUS = new QPushButton(AMKeyboard);
        pushButtonMINUS->setObjectName(QStringLiteral("pushButtonMINUS"));
        pushButtonMINUS->setGeometry(QRect(1140, 100, 68, 68));
        pushButtonMINUS->setFocusPolicy(Qt::NoFocus);
        pushButtonMINUS->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-radius: 10px;\n"
"color:rgb(255,251,240);\n"
"font-size:28px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonOK = new QPushButton(AMKeyboard);
        pushButtonOK->setObjectName(QStringLiteral("pushButtonOK"));
        pushButtonOK->setGeometry(QRect(1140, 180, 68, 148));
        pushButtonOK->setFocusPolicy(Qt::NoFocus);
        pushButtonOK->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-radius: 10px;\n"
"color:rgb(255,251,240);\n"
"font-size:28px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));
        pushButtonPLUS = new QPushButton(AMKeyboard);
        pushButtonPLUS->setObjectName(QStringLiteral("pushButtonPLUS"));
        pushButtonPLUS->setGeometry(QRect(1140, 20, 68, 68));
        pushButtonPLUS->setFocusPolicy(Qt::NoFocus);
        pushButtonPLUS->setStyleSheet(QLatin1String("QPushButton{\n"
"border:2px solid #0fbacd;\n"
"border-radius: 10px;\n"
"color:rgb(255,251,240);\n"
"font-size:28px;\n"
"background:rgba(29, 165, 219, 0.3);\n"
"}"));

        retranslateUi(AMKeyboard);

        QMetaObject::connectSlotsByName(AMKeyboard);
    } // setupUi

    void retranslateUi(QWidget *AMKeyboard)
    {
        AMKeyboard->setWindowTitle(QApplication::translate("AMKeyboard", "Form", nullptr));
        pushButtonQ->setText(QApplication::translate("AMKeyboard", "Q", nullptr));
        pushButtonA->setText(QApplication::translate("AMKeyboard", "A", nullptr));
        pushButtonZ->setText(QApplication::translate("AMKeyboard", "Z", nullptr));
        pushButtonSPACE->setText(QApplication::translate("AMKeyboard", "SPACE", nullptr));
        pushButtonX->setText(QApplication::translate("AMKeyboard", "X", nullptr));
        pushButtonS->setText(QApplication::translate("AMKeyboard", "S", nullptr));
        pushButtonW->setText(QApplication::translate("AMKeyboard", "W", nullptr));
        pushButtonC->setText(QApplication::translate("AMKeyboard", "C", nullptr));
        pushButtonD->setText(QApplication::translate("AMKeyboard", "D", nullptr));
        pushButtonE->setText(QApplication::translate("AMKeyboard", "E", nullptr));
        pushButtonV->setText(QApplication::translate("AMKeyboard", "V", nullptr));
        pushButtonF->setText(QApplication::translate("AMKeyboard", "F", nullptr));
        pushButtonR->setText(QApplication::translate("AMKeyboard", "R", nullptr));
        pushButtonB->setText(QApplication::translate("AMKeyboard", "B", nullptr));
        pushButtonG->setText(QApplication::translate("AMKeyboard", "G", nullptr));
        pushButtonT->setText(QApplication::translate("AMKeyboard", "T", nullptr));
        pushButtonN->setText(QApplication::translate("AMKeyboard", "N", nullptr));
        pushButtonH->setText(QApplication::translate("AMKeyboard", "H", nullptr));
        pushButtonY->setText(QApplication::translate("AMKeyboard", "Y", nullptr));
        pushButtonM->setText(QApplication::translate("AMKeyboard", "M", nullptr));
        pushButtonJ->setText(QApplication::translate("AMKeyboard", "J", nullptr));
        pushButtonU->setText(QApplication::translate("AMKeyboard", "U", nullptr));
        pushButtonSEP->setText(QApplication::translate("AMKeyboard", "\\", nullptr));
        pushButtonI->setText(QApplication::translate("AMKeyboard", "I", nullptr));
        pushButtonK->setText(QApplication::translate("AMKeyboard", "K", nullptr));
        pushButtonORR->setText(QApplication::translate("AMKeyboard", "|", nullptr));
        pushButtonO->setText(QApplication::translate("AMKeyboard", "O", nullptr));
        pushButtonL->setText(QApplication::translate("AMKeyboard", "L", nullptr));
        pushButtonP->setText(QApplication::translate("AMKeyboard", "P", nullptr));
        pushButtonDOLLAR->setText(QApplication::translate("AMKeyboard", "$", nullptr));
        pushButtonBACKSPACE->setText(QApplication::translate("AMKeyboard", "BACK\n"
"SPACE", nullptr));
        pushButtonSHARP->setText(QApplication::translate("AMKeyboard", "#", nullptr));
        pushButtonDIV->setText(QApplication::translate("AMKeyboard", "/", nullptr));
        pushButtonMUTIPLY->setText(QApplication::translate("AMKeyboard", "*", nullptr));
        pushButtonRIGHT->setText(QApplication::translate("AMKeyboard", "RIGHT", nullptr));
        pushButtonLEFT->setText(QApplication::translate("AMKeyboard", "LEFT", nullptr));
        pushButton9->setText(QApplication::translate("AMKeyboard", "9", nullptr));
        pushButton1->setText(QApplication::translate("AMKeyboard", "1", nullptr));
        pushButton2->setText(QApplication::translate("AMKeyboard", "2", nullptr));
        pushButton8->setText(QApplication::translate("AMKeyboard", "8", nullptr));
        pushButton6->setText(QApplication::translate("AMKeyboard", "6", nullptr));
        pushButton7->setText(QApplication::translate("AMKeyboard", "7", nullptr));
        pushButton4->setText(QApplication::translate("AMKeyboard", "4", nullptr));
        pushButton3->setText(QApplication::translate("AMKeyboard", "3", nullptr));
        pushButton5->setText(QApplication::translate("AMKeyboard", "5", nullptr));
        pushButtonDOT->setText(QApplication::translate("AMKeyboard", ".", nullptr));
        pushButton0->setText(QApplication::translate("AMKeyboard", "0", nullptr));
        pushButtonMINUS->setText(QApplication::translate("AMKeyboard", "-", nullptr));
        pushButtonOK->setText(QApplication::translate("AMKeyboard", "OK", nullptr));
        pushButtonPLUS->setText(QApplication::translate("AMKeyboard", "+", nullptr));
    } // retranslateUi

};

namespace Ui {
    class AMKeyboard: public Ui_AMKeyboard {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_AMKEYBOARD_H
