./objects/main.o: SWSC_App\main.c D:\keil\ARM\ARMCLANG\include\string.h \
  RTE\Device\TLD4020-4ET\device.h RTE\_Target_1\RTE_Components.h \
  RTE\Device\TLD4020-4ET\variants.h RTE\Device\TLD4020-4ET\tld40xx_4et.h \
  D:\keil\ARM\CMSIS\5.9.0\CMSIS\Core\Include\core_cm23.h \
  D:\keil\ARM\ARMCLANG\include\stdint.h \
  D:\keil\ARM\CMSIS\5.9.0\CMSIS\Core\Include\cmsis_version.h \
  D:\keil\ARM\CMSIS\5.9.0\CMSIS\Core\Include\cmsis_compiler.h \
  D:\keil\ARM\CMSIS\5.9.0\CMSIS\Core\Include\cmsis_armclang.h \
  RTE\Device\TLD4020-4ET\system_tld40xx.h RTE\Device\TLD4020-4ET\types.h \
  D:\keil\ARM\ARMCLANG\include\stdbool.h \
  RTE\Device\TLD4020-4ET\error_codes.h \
  RTE\Device\TLD4020-4ET\cmsis_misra.h RTE\Device\TLD4020-4ET\scu.h \
  RTE\Device\TLD4020-4ET\scu_defines.h RTE\Device\TLD4020-4ET\pmu.h \
  RTE\Device\TLD4020-4ET\pmu_defines.h RTE\Device\TLD4020-4ET\adc11.h \
  RTE\Device\TLD4020-4ET\adc11_defines.h RTE\Device\TLD4020-4ET\ldrv.h \
  RTE\Device\TLD4020-4ET\ldrv_defines.h RTE\Device\TLD4020-4ET\gpio.h \
  RTE\Device\TLD4020-4ET\gpio_defines.h RTE\Device\TLD4020-4ET\cpu.h \
  RTE\Device\TLD4020-4ET\cpu_defines.h RTE\Device\TLD4020-4ET\mem.h \
  RTE\Device\TLD4020-4ET\mem_defines.h RTE\Device\TLD4020-4ET\lin.h \
  RTE\Device\TLD4020-4ET\lin_defines.h RTE\Device\TLD4020-4ET\bootrom.h \
  Generated\genLinConfig.h Protocol\lin_type.h Protocol\lin_driver_api.h \
  Protocol\lin_main.h Hal\lin_hal.h Protocol\lin_diag_tp.h \
  SWSC_App\LINApplication.h SWSC_App\main.h modules\ModuleBattery.h \
  modules\ModuleAdc.h System\SystemMain.h System\SystemType.h \
  D:\keil\ARM\ARMCLANG\include\stddef.h modules\ModuleFlash.h \
  modules\flash.h
