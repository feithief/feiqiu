./objects/moduletemperature.o: modules\ModuleTemperature.c \
  modules\ModuleTemperature.h modules\ModuleAdc.h \
  D:\keil\ARM\ARMCLANG\include\stdint.h RTE\Device\TLD4020-4ET\adc11.h \
  RTE\Device\TLD4020-4ET\variants.h RTE\_Target_1\RTE_Components.h \
  RTE\Device\TLD4020-4ET\tld40xx_4et.h \
  D:\keil\ARM\CMSIS\5.9.0\CMSIS\Core\Include\core_cm23.h \
  D:\keil\ARM\CMSIS\5.9.0\CMSIS\Core\Include\cmsis_version.h \
  D:\keil\ARM\CMSIS\5.9.0\CMSIS\Core\Include\cmsis_compiler.h \
  D:\keil\ARM\CMSIS\5.9.0\CMSIS\Core\Include\cmsis_armclang.h \
  RTE\Device\TLD4020-4ET\system_tld40xx.h RTE\Device\TLD4020-4ET\types.h \
  D:\keil\ARM\ARMCLANG\include\stdbool.h \
  RTE\Device\TLD4020-4ET\error_codes.h \
  RTE\Device\TLD4020-4ET\cmsis_misra.h \
  RTE\Device\TLD4020-4ET\adc11_defines.h modules\ModuleClock.h \
  System\SystemType.h D:\keil\ARM\ARMCLANG\include\stddef.h \
  modules\ModuleBattery.h modules\ModuleLed.h \
  RTE\Device\TLD4020-4ET\ldrv_defines.h modules\ModuleFlash.h \
  RTE\Device\TLD4020-4ET\pmu.h RTE\Device\TLD4020-4ET\pmu_defines.h
