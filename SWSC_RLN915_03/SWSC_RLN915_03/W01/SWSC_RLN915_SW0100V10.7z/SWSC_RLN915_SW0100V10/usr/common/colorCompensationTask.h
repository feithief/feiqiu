#ifndef COLOR_COMP_TASK_H
#define COLOR_COMP_TASK_H

#include <appConfig.h>
#include <softTimerTask.h>
#include <taskManager.h>
#include <ColorMixingTask.h>
#include <measureTask.h>
#include <safetyMonitorTask.h>



void CCP_TaskHandler(void);














#endif